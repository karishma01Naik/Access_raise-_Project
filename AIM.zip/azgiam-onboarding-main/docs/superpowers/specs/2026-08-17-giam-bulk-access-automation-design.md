# GIAM Bulk Access Request Automation — Design Spec

**Status:** Implemented and verified end-to-end against production with a
single real self-test submission (2026-08-20) — pending the bulk/on-behalf-of
usage sign-off (Section 9.1) before any real multi-recipient batch.
**Date:** 2026-08-17 (revised 2026-08-18: superseded the browser-automation
approach after discovering the `lrp` CLI, a first-party wrapper around the
LRP/GIAM API; revised 2026-08-19: v1 runs locally per-operator using each
operator's own SSO session instead of the shared TU account; revised
2026-08-20: implementation complete (`bulkprovision/`, 120 automated tests),
`cli.main()` now auto-invokes `lrp login` with an automatic `--manual`
fallback, a real production submission was verified end-to-end, the
separate catalogue Excel/validation step was removed in favor of live
`lrp search-products` validation, and the submission mechanism was switched
from the cart flow (`add-to-cart`/`submit-cart`) to `lrp order-product`
(one call per row, no cart at all) after real bulk runs kept hitting an
empty cart for every recipient tried - see Section 5)
**Author:** Operations team

## 1. Problem Statement

Access requests for new joiners and existing team members are raised manually
through the GIAM portal (`giam.web.allianz`), one user and one access group at
a time. For a typical team onboarding (10–15 users × up to 20 GIAM roles each,
i.e. up to ~300 individual request line items), this is slow, repetitive, and
error-prone, with no consolidated view of what was requested for whom or what
succeeded/failed.

## 2. Goals

- Accept a bulk list of (user, GIAM group) pairs as input.
- Validate every requested group before submitting anything (originally
  against a separately-maintained approved-group catalogue; as of
  2026-08-20, via a live `lrp search-products` existence check instead —
  see Section 5).
- Submit all valid requests to GIAM on behalf of the requestor.
- Produce a status report (success / failed / pending) after each run.
- Allow failed rows to be retried without re-entering the full input.

## 3. Non-Goals (out of scope for v1)

- De-provisioning / access revocation.
- Approval-workflow logic inside GIAM itself (GIAM's own downstream approval,
  if any, is untouched — this tool only raises the request).
- Attestation handling (`lrp` supports listing/deciding attestations, but
  that's a separate workflow from bulk provisioning — not built here).
- Free-text / chat-driven input parsing.
- Scheduled/unattended recurring runs (v1 is on-demand, human-triggered).
- Building or maintaining a GIAM sandbox/test environment.
- Centralized/shared-account execution (the TU account model from the
  previous revision is deferred, not adopted, for v1 — see Section 5).

## 4. Why This Is Automation, Not an AI Agent

The originating idea framed this as an "AI Agent." The input is a maintained
Excel/Confluence-derived list, not free-text chat, and GIAM access is now
known to be reachable via a documented API (through the `lrp` CLI, see
Section 5) rather than only a UI. Every step in the pipeline is deterministic:

| Step | Deterministic approach | Why not an LLM |
|---|---|---|
| Parse input | Excel parsing (pandas/openpyxl) | No natural language to interpret |
| Validate group names | Live `lrp search-products` existence check per requested group (no separate catalogue as of 2026-08-20 — see Section 5) | Deterministic lookup is more reliable and auditable than model judgment |
| Submit request | Shell out to the `lrp` CLI (`find-user`, `order-product --on-behalf-of`, one call per row) | A documented, first-party CLI wrapping a real API is strictly more reliable than either browser automation or an LLM computer-use agent |
| Check status | `lrp list-orders` — structured JSON | No scraping, no generation task |
| Report | Template-based Excel/HTML generation | No generation task requiring a model |

**Decision: build this as a script that orchestrates the `lrp` CLI, not an
LLM-based agent.** If a future version needs to accept free-text requests
("give Priya the AWS admin role"), an LLM parsing step can be added in front
of the same deterministic pipeline — the pipeline itself should not change.

**One deliberate exception, added 2026-08-20 (`bulkprovision/ai_summary.py`):**
after all results are computed deterministically, an optional step asks the
operator's local Claude Code CLI (`claude -p ...`) to phrase the
*already-decided* per-row outcomes as a readable plain-English summary for
Cloud Ops. This does not violate the "no AI in the decision pipeline"
principle above — the model never sees raw `lrp` responses and never
classifies or re-judges anything; it only formats results that
`orchestrator.py` already computed. It's best-effort and silently skipped
if `claude` isn't installed or the call fails, and never affects the
deterministic report or exit code. Uses the operator's own local Claude
Code profile — no separate API key or AWS Bedrock wiring needed (matching
the intent noted in Section 10's Open Questions).

## 5. Architecture

The `lrp` CLI (repo: `lrp-cli`, internal Go tool) wraps the LRP API that sits
in front of GIAM/One Identity Manager. It already provides every primitive
this project needs: user lookup, product/role search, cart-based bulk
ordering with native on-behalf-of support, order listing, and cancellation —
all with JSON I/O designed for non-interactive/scripted use (its own docs
note it's designed to be driven by AI coding tools with stdin piped). This
replaces the originally-planned Playwright browser automation entirely.

**Execution model (v1): local, per-operator.** The tool runs on each
operator's own machine, authenticated via their own personal SSO session
(`lrp login`, no shared TU account). Whoever runs a batch — for their own
team's onboarding — logs in as themselves first. This trades the shared-TU
blast-radius/sign-off concerns (Section 8 of the prior revision) for a
simpler, accurate audit trail (GIAM sees the real requester), at the cost
of needing every operator to have `lrp` installed and configured locally,
and needing to confirm each operator's own account actually has
`--on-behalf-of` rights (see Open Questions). A shared TU/centralized model
remains a possible future iteration, not v1.

```
                  ┌─────────────────────┐
                  │  Input Excel         │  (recipient, GIAM group, justification)
                  └──────────┬──────────┘
                             │
                  ┌──────────▼──────────┐
                  │  Validation           │  lrp search-products per
                  │  (found via live      │  requested group — no
                  │   lrp search-products?)│  separate catalogue (2026-08-20)
                  └──────────┬──────────┘
                             │
                    valid rows│invalid rows
                             │      │
                             │      ▼
                             │  ┌──────────────┐
                             │  │ Error/rejected│──► included in report,
                             │  │ (not submitted)│    never sent to lrp
                             │  └──────────────┘
                  ┌──────────▼──────────┐
                  │ LRP CLI Orchestrator  │  shells out to `lrp` per
                  │ (per recipient:       │  recipient: find-user, then
                  │  find-user, then      │  one order-product call per
                  │  order-product per    │  row --on-behalf-of <user> -
                  │  row, no cart)         │  no cart, no batching
                  └──────────┬──────────┘
                             │
                  ┌──────────▼──────────┐
                  │ Status Collector      │  `lrp list-orders`,
                  │                       │  structured JSON per order
                  └──────────┬──────────┘
                             │
                  ┌──────────▼──────────┐      ┌────────────────────┐
                  │ Report Generator      │      │ Retry Store         │
                  │ (success/warning/     │─────►│ (failed rows +      │
                  │  error, per row)      │      │  reason, keyed by   │
                  └───────────────────────┘      │  run ID)            │
                                                  └────────────────────┘
```

### Components

- **Validation** — per requested group, `lrp search-products` (called live
  inside the orchestrator, not a separate pre-check step) either finds a
  match or raises `PRODUCT_NOT_FOUND`; a not-found group becomes an `error`
  row for that group alone, without blocking any of that recipient's other,
  valid groups. There is no separate approved-groups catalogue as of
  2026-08-20 (see Section 9's former Blocker 3, and Section 10).
- **LRP CLI Orchestrator** (`bulkprovision/orchestrator.py`) — a script that,
  per recipient: calls `lrp find-user` once to resolve the recipient (email,
  name, or ID) to a full user object, then for each of that recipient's
  requested groups, calls `lrp search-products` followed by one independent
  `lrp order-product --product '<product JSON>' --reason "..."
  --on-behalf-of <user JSON>` call. **Submits via `order-product`, not the
  cart (`add-to-cart`/`get-cart`/`submit-cart`), as of 2026-08-20.**
  `order-product`'s own docs describe it as submitting "a single product
  order directly without using the cart" — switched to this after two
  attempted fixes to the cart flow (filtering `get-cart`'s response, then
  reading `add-to-cart`'s own response instead of a separate `get-cart`
  call) still left every real bulk run hitting an empty cart immediately
  after a successful `add-to-cart`, for every recipient tried, including
  ones known to already have the access (ruling out a permissions cause).
  `order-product` has no cart step at all, so that entire failure class -
  and the cross-recipient cart-isolation risk it was tangled up with (a
  leftover item from a prior recipient's failed submission getting
  submitted for the next recipient) - no longer exists: each row is now a
  single, fully independent API call (`/api/products/order`, a different
  endpoint than the cart's `/api/cart/submit`), so one row's outcome can
  never affect any other row, for this recipient or any other. The only
  batching left is result classification, unchanged from the cart flow:
  duplicate detection via `nonRequestableProducts` and `RESULT_MESSAGES`
  (Section 7) work identically since both endpoints return the same
  `OrderResponse` shape (`result`/`message`/`nonRequestableProducts`).
- **Status Collector** — calls `lrp list-orders` after submission to capture
  each order's structured status; no scraping involved.
- **Report Generator** — writes a per-run Excel/HTML report: one row per
  (user, group) with status and, if failed, a reason string.
- **Retry Store** — a local file/table (e.g. SQLite or JSON) keyed by run ID,
  holding only failed rows + reasons, so a retry run doesn't require
  re-uploading the original Excel.
- **Interactive Menu** (`bulkprovision/interactive.py`, added 2026-08-20) —
  a menu wrapping every lrp operation the tool uses (run a batch, check
  auth, log in, find a user, search a product, list orders) so an operator
  never has to type a raw `lrp` command directly. Launched by running the
  CLI with no `--input` (or an explicit `--interactive` flag). Its "log in"
  option always forces a genuinely fresh authentication
  (`client.login(force=True)`) rather than silently trusting whatever
  cookie is already cached — see Section 8's note on the burned-cookie
  incident that motivated this.

## 6. Data Flow (per run)

1. Requester provides/updates the input Excel (recipient, GIAM group,
   justification).
2. Unparseable rows (blank recipient/group) are set aside up front and
   reported as `rejected` without being submitted. There is no separate
   catalogue pre-check — group validity is checked live via
   `lrp search-products` per row, inside step 4b below.
3. `cli.main()` checks `lrp check-auth` itself; if not authenticated, it
   invokes `lrp login` automatically (opening a browser for the operator's
   own SSO), falling back to `lrp login --manual` automatically if the
   automated browser fails (confirmed in practice: its isolated Chromium
   doesn't share the operator's regular browser's certificate trust store —
   see Section 9.6). The operator no longer runs `lrp login` as a separate
   manual step first, though they still complete SSO/MFA interactively
   either way.
4. LRP CLI Orchestrator processes recipients one at a time:
   a. `lrp find-user <recipient>` → resolve to a full user object.
   b. For each of that user's requested groups, `lrp search-products` to get
      the current product JSON — this live call is the *only* existence
      check (no separate catalogue); a group it can't find raises
      `PRODUCT_NOT_FOUND` and becomes an `error` row for that group alone,
      without blocking this recipient's other groups.
   c. `lrp order-product --product '<product JSON>' --reason
      "<justification>" --on-behalf-of '<user JSON>'` — one independent call
      per row, no cart involved at all (switched from
      add-to-cart/get-cart/submit-cart on 2026-08-20 — see Section 5). A
      duplicate-flagged product (present in the response's
      `nonRequestableProducts`) is always classified `warning`, even if the
      overall `result` is `error` (e.g. a genuine duplicate) — see Section 7.
      One row's outcome never affects any other row.
5. **Not yet wired in** (`lrp_client.list_orders()` exists and is tested, but
   `cli.py` doesn't call it): the original design called for a Status
   Collector to run `lrp list-orders` and cross-check submission results
   against actual GIAM approval status. Today, `report.csv` reflects only
   `lrp`'s immediate `order-product` response; checking real GIAM status
   (`Pending`/`Approved`/`Rejected`) is a manual `lrp list-orders` step for
   now (see README "Verifying a submission actually landed in GIAM").
6. Report Generator produces the run's status report. **`cli.run_batch`
   also prints each row's status line to the terminal as soon as that row
   is done (added 2026-08-21), via an `on_result` callback threaded through
   `process_all`/`process_recipient`** — an operator watching a
   multi-row batch sees live progress (`[i/N] recipient | group | status |
   message`) rather than a silent terminal until the final summary line.
7. Failed rows (`status == "error"` only — `warning` rows are correctly
   excluded) are written to the Retry Store; retrying today means
   hand-building a new input Excel from `retry.json`'s rows, not yet a
   direct `--retry-in` flag (see Open Questions).

## 7. Error Handling & Retry

The CLI's own result semantics replace the need for custom scraping/error
inference:

- **Unparseable row** (blank recipient/group) — never submitted; reported
  immediately as `rejected` with reason.
- **Group not found via `lrp search-products`** — that group alone is never
  submitted; reported as `error` with lrp's own reason (e.g. "not found"),
  added to the Retry Store, without blocking this recipient's other, valid
  groups.
- **Any product flagged in the response's `nonRequestableProducts` is always
  `warning`**, checked *before* the overall `result` — even when `result`
  itself is `"error"` (this happens when *all* requested products are
  duplicates, e.g. `ERROR_ONE_ON_BEHALF_ALL_DUPLICATES`). Retrying an
  already-has-it row achieves nothing and would clutter the Retry Store
  forever, so duplicate-flagged rows never enter it. Its message always
  leads with a direct, unambiguous sentence — *"This request was already
  submitted/assigned previously for this user."* — followed by lrp's own
  detail in parentheses for traceability, rather than surfacing only the
  more technical humanized lrp text on its own (added 2026-08-20, per
  direct operator feedback that the reason needed to be immediately clear
  without reading lrp's own message vocabulary).
- **`result: "error"` for a non-duplicate reason** (e.g. `ERROR_ORDER_FAILED`)
  — nothing was ordered for that call; row marked `error` with the
  humanized `message` (verbatim from `lrp-cli`'s own message map), added to
  Retry Store.
- **`order-product` raises an `LrpError`** (e.g. a transport/timeout failure,
  not a duplicate/business outcome) — marks that single row `error` with
  the exception's message; other rows for the same recipient are
  unaffected, since each row is now an independent call (see Section 5).
  There is no cart-related error class anymore (`add-to-cart` failure,
  empty-cart-after-add) — that entire failure class no longer exists once
  the cart itself was removed from the submission path on 2026-08-20.
- **Session/auth failure mid-run** — an `LrpError` from any `lrp_client` call
  (including `AUTH_EXPIRED`/`HTTP_ERROR`/timeout) becomes an `error` row for
  that recipient; processing continues to the next recipient rather than
  hard-stopping. **Not yet implemented:** the originally-planned hard-stop
  behavior (break out of the batch entirely on an auth-expiry-flavored
  error, rather than treating it as an ordinary per-recipient failure) —
  tracked as a follow-up, not built (see Open Questions).
- **Pre-flight authentication** is now handled proactively, not just
  detected: `cli.main()` calls `lrp check-auth` itself before processing
  anything, and if not authenticated, calls `lrp login` automatically
  (falling back to `lrp login --manual` if the automated browser fails —
  see Section 9.6) rather than just erroring out and telling the operator
  to run it themselves.
- Retries are **manual/human-triggered** for v1 — the operator reviews the
  failed/error list and explicitly re-runs it. `retry.json` isn't yet
  consumable directly as CLI input (see Open Questions).

## 8. Security Considerations

**Decision:** run the tool locally on each operator's own machine,
authenticated as themselves via `lrp login` (browser-based SSO,
cookie-based session) — not the shared TU account `tu-pculxai`. This
resolves most of the shared-account concerns from the prior revision, but
introduces different ones:

- **Accurate audit attribution (improvement).** GIAM/LRP's logs now show
  the real operator as the actor for every submitted request — no shared
  identity to disambiguate.
- **Per-operator on-behalf-of rights (partially confirmed).** A real
  self-test (2026-08-20) confirmed an operator's own account can submit
  `--on-behalf-of` **themselves** successfully. It's still **not** confirmed
  that an arbitrary operator's personal account has `--on-behalf-of`
  delegation for genuinely **different** recipients (colleagues, other
  team members) — this must be verified per operator, not assumed from one
  self-test (see Open Questions).
- **Session cookie handling.** `lrp login` produces a session cookie valid
  roughly 1 hour. It's shorter-lived than a permanent credential but still
  grants the ability to act as that operator for that window, and must be
  handled like a secret on their local machine — not left in shell history
  or logs. This applies equally whether the cookie came from the automated
  browser flow or the `--manual` paste fallback (Section 9.6) — a pasted
  cookie value is just as sensitive and must never be shared (e.g. pasted
  into a chat/ticket) once captured.
- **Real incident (2026-08-20):** during this project's own testing, an
  operator pasted their real session cookie into a chat conversation
  (asking whether the CLI's manual-login validation had worked). The
  cookie was treated as burned: cleared from the local `lrp` config, never
  echoed back or written to any file, and `login()` gained a `force`
  parameter (`lrp login --force`) so an operator can always obtain a
  guaranteed-fresh session rather than trusting whatever is cached — the
  interactive menu's "Log in" option always sets this. Lesson encoded
  directly in the README: never paste a session cookie anywhere but the
  `lrp login --manual` prompt itself.
- **Login is now automatic, not a separate manual step.** `cli.main()` calls
  `lrp check-auth` and, if needed, `lrp login` itself (Section 6 step 3) —
  the operator still completes SSO/MFA interactively, but no longer runs
  `lrp login` themselves before invoking the tool. This still ties
  automation to a human being present at the start of each run — acceptable
  for v1's on-demand model.
- **No shared blast radius.** Unlike the TU model, a compromised or misused
  session only affects that individual operator's own account, not four
  unrelated systems.
- Input Excel may contain PII (names/emails, BIDs) — handled per existing
  data retention rules; not yet defined for this tool (see Open Questions).

## 9. Real Blockers

These are not "nice to resolve" — they can each independently stop this
project or force a redesign, and none are solved by better code:

1. **Bulk/on-behalf-of usage sign-off (highest remaining risk, but lower
   than before).** The `lrp` CLI is a sanctioned first-party tool, not
   unauthorized scripting against a UI — its own docs describe
   `--on-behalf-of` and AI-tool-driven usage as intended, and a real
   self-test submission (2026-08-20, self-`--on-behalf-of`) confirmed the
   mechanics work end-to-end. What's still unconfirmed is whether **bulk,
   scripted, whole-team submissions on behalf of genuinely different
   recipients** fall within accepted use, versus the tool's likely intended
   pattern of one person ordering for a few colleagues at a time — and
   whether a typical operator's own account even has `--on-behalf-of`
   delegation for arbitrary team members (vs. only direct reports, if
   scoped that way). Confirm with whoever owns the LRP CLI / GIAM platform
   before any real multi-recipient batch run.
2. **No confirmed test/staging LRP instance.** `LRP_BASE_URL` defaults to
   production (`lrp.giam.allianz`); no separate environment is confirmed for
   safe development/testing.
3. ~~**Catalogue drift.** The approved-groups catalogue lives on Confluence;
   the tool validates against an Excel copy, cross-checked against live
   `lrp search-products` results. If the Excel isn't kept in sync, valid
   catalogue entries may be rejected, or (if the sync direction is reversed)
   stale entries may pass. No owner or refresh process defined yet.~~
   **Resolved (2026-08-20):** there's no local catalogue copy anymore —
   `lrp search-products` itself validates each requested group live, so
   there's nothing to keep in sync. Trade-off: any group `lrp` can find is
   now requestable, not just ones a team pre-approved for bulk use (see
   Section 10's now-removed catalogue cross-check question).
4. **Session window vs. batch size.** An operator's login session lasts
   roughly an hour. Cart-based per-recipient submission (Section 6) is far
   more efficient than one submission per role, so a 10–15 user batch
   likely fits in one session — but this isn't measured against a real
   multi-recipient batch yet (only a single-recipient self-test), and a
   mid-batch re-login needs to be an acceptable, well-tested path rather
   than a surprise (see Section 7 — the hard-stop-on-expiry behavior isn't
   built yet; today an auth failure just becomes an ordinary per-recipient
   error).
5. **Data retention and PII handling** for the input Excel (names, BIDs,
   justifications) and run logs is not yet defined — needs an owner
   decision before production use.
6. **`lrp login`'s automated browser can fail with a certificate error even
   when the operator's regular browser and `curl` both work fine** —
   observed directly, not theoretical. (Earlier revisions of this doc said
   this was "confirmed on two independent real machines" — that overstated
   the evidence: the Bash tool used to investigate this and the operator's
   own terminal turned out to share the same underlying machine/filesystem,
   so this is one machine observed twice, not two independent ones. The
   finding itself — automated Chromium fails while curl/regular browser
   succeed — still stands; only the "independent machines" framing was
   wrong.) Root cause: the isolated Chromium instance `lrp login` launches
   (via `go-rod`'s launcher) doesn't share the OS/regular-browser
   certificate trust store, so a corporate root CA trusted everywhere else
   isn't trusted there. `bulkprovision`'s `login()` now automatically falls
   back to `lrp login --manual` when the browser attempt fails fast, which
   fully works around this in practice (verified) — but the underlying browser
   trust gap itself remains unresolved and could resurface in a different
   form (e.g. if `--manual`'s own validation call path changes).

**Superseded by the `lrp` CLI discovery (no longer blockers):** GIAM having
no API, needing browser RPA sign-off for UI scripting, portal UI fragility,
scraping-based status detection, and ~300 individual UI actions per run are
all resolved by using the documented API/CLI instead.

## 10. Open Questions / Assumptions

- Assumed: GIAM's own downstream approval process (if any) is unaffected —
  this tool only automates *raising* the request, not approving it.
- Whether every operator's own account has `--on-behalf-of` delegation for
  arbitrary *different* recipients, not just direct reports or themselves —
  self-`--on-behalf-of` is confirmed working; genuinely-different-recipient
  delegation is not — needs verifying per operator (see Blocker 9.1).
- **Resolved/moot (2026-08-20):** the former question of whether to reject a
  row present in a catalogue allow-list but not found via
  `lrp search-products` no longer applies — there is no catalogue allow-list
  anymore; `lrp search-products` alone decides, and a not-found group
  already becomes an `error` row (see Section 9's former Blocker 3).
- **Built (2026-08-20):** the intent to reuse each operator's existing local
  Claude Code profile/session rather than provisioning separate LLM API
  access is now realized in `bulkprovision/ai_summary.py` (see Section 4)
  for the optional plain-English run summary. A future free-text-input-parsing
  LLM step, if ever needed, would use the same approach.
- Data retention period for input files, run logs, and reports is not yet
  defined — needs an owner decision.
- Long-term ownership of this tool (Cloud Ops vs. a platform team) is not
  yet assigned.
- Hard-stop-on-session-expiry (Section 7) and `retry.json` as direct CLI
  input (`--retry-in`) are both designed-for but not built — tracked as v1.1
  follow-ups, not silently dropped.
- Root cause of the `lrp login` browser certificate-trust gap (Blocker 9.6)
  is unresolved — `--manual` is a full practical workaround, not a fix to
  the underlying Chromium trust-store mismatch.

## 11. Run Checkpoints

Every run should validate these checkpoints **in order**, failing fast and
reporting exactly which checkpoint failed — not a generic error. This
doubles as the manual test checklist before any build work starts, and as
the automation's own step-by-step run log once built.

**Pre-flight (before any submission):**

1. `lrp check-auth` succeeds for the operator's own session — confirms
   authentication, whether from an already-valid cookie or from `cli.main()`
   automatically invoking `lrp login` (with automatic `--manual` fallback)
   moments earlier.
2. Input Excel parses with all required columns present (recipient,
   giam_group, justification). Rows with a blank recipient/group are
   surfaced as `rejected`, not silently dropped.

**Per-recipient (during submission):**

3. `lrp find-user <recipient>` resolves to **exactly one** user. When
   `recipient` looks like an email address, `find_user()` *always* requires
   an exact case-insensitive email match on one of the returned accounts
   (added 2026-08-20) — this is checked regardless of how many results came
   back. This matters even when `find-user` returns only a single result:
   a real case was found where searching an email returned exactly one
   account, but that account's own `email` field was a completely different
   admin/service address (e.g. an M365 admin account on
   `@allianzms.onmicrosoft.com`) — silently trusting "the only result" would
   have submitted access on behalf of the wrong account. Zero exact-email
   matches or more than one is a checkpoint failure (`USER_NOT_FOUND` /
   `AMBIGUOUS_USER`, with the recipient and match count in the message), not
   a silent pick of whatever came back. **Confirmed 2026-08-21:** some
   account types (M365 admin/service accounts, e.g.
   `adm_wgbh5c9@allianzms.onmicrosoft.com`) have a completely blank `email`
   field in `find-user`'s response - the real address only appears embedded
   as a suffix of the display `name` (e.g. "Lakhpati, Sachin (Allianz
   Technology SE) - M365 Admin Account - adm_wgbh5c9@allianzms.onmicrosoft.com").
   `find_user()` falls back to a `name`-suffix match *only* for accounts
   whose `email` is blank/missing - never to override an account whose
   `email` is populated with something else, which would defeat the entire
   point of requiring an exact match. If neither the email nor the
   name-suffix fallback matches, the error message includes every
   candidate's actual `email`/`name` values for direct diagnosis.
4. `lrp search-products` confirms each requested group exists in LRP — this
   is the sole validation step (no catalogue as of 2026-08-20); a not-found
   group becomes an `error` row for that group without blocking the
   recipient's other groups.
5. `lrp order-product --on-behalf-of` returns `result: success` or `warning`
   (not `error`) for each of the recipient's requested groups — one
   independent call per row, no cart step (since 2026-08-20).

**Post-submission:**

6. **Not yet built:** `lrp list-orders` cross-checking submission results
   against real GIAM status. Today this checkpoint is a manual step (see
   README "Verifying a submission actually landed in GIAM"), not part of
   the tool's own run.
7. Every submitted row has a captured status (submitted / warning /
   rejected / error) — no row silently dropped.
8. Report covers 100% of input rows: valid+submitted, invalid+rejected, and
   any that failed submission.
9. Failed rows appear in the Retry Store with a reason string, not just a
   pass/fail flag.

## 12. Testing Strategy

- **Done:** 120 automated tests across every module (`bulkprovision/`,
  `tests/`) — pure-Python logic (validation, orchestration, reporting)
  tested via dependency-injected fake clients, and the `lrp_client` wrapper
  tested via mocked `subprocess.run`, so the suite never touches the real
  `lrp` binary or network. Run with `python3 -m pytest -v`.
- **Done:** a real production self-test submission (2026-08-20, on the
  earlier cart-based flow) — one recipient (the operator, on behalf of
  themselves), one group, verified end-to-end from `./azgiam-onboarding.sh`
  through a real `lrp submit-cart` call, with the result independently
  checked against `lrp list-orders`.
- **Still not done:** a real multi-recipient batch on the current
  `order-product` flow hasn't yet succeeded end-to-end — real bulk attempts
  on the cart flow repeatedly hit an empty-cart failure for every recipient
  (Section 5), which is the reason for the 2026-08-20 switch to
  `order-product`; that switch itself is not yet confirmed against
  production. No staging LRP instance is confirmed, so this remains a
  production-only test surface.
- **Not built:** a `--dry-run` mode (resolve users/products, log the
  intended order, skip `order-product`) — still recommended before any real
  multi-recipient batch, given Blockers 9.1/9.2 are open, but not
  implemented. `search-products`/`find-user` (no-auth, MeiliSearch-backed)
  can still be used ad hoc for a lower-effort manual sanity check today.

## 13. Rollout Plan

1. Resolve the bulk/on-behalf-of usage sign-off (Section 9.1).
2. ~~Build validation + dry-run mode~~ — validation is built; dry-run mode
   is not (see Section 12). Do this before step 3 if it hasn't landed yet.
3. Pilot: run live submissions for one small team (manually supervised),
   compare tool-reported status against `lrp list-orders` and a manual
   portal check. A single-recipient self-test has already passed
   (2026-08-20); this step is the first *multi-recipient, different-people*
   test.
4. Expand to standard team-onboarding batches once the pilot matches
   expectations.
