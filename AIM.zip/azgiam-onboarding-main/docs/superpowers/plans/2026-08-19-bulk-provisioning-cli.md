# GIAM Bulk Provisioning Tool Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A Python CLI tool, run locally by each operator on their own machine, that reads an Excel list of (recipient, GIAM group, justification) rows, validates them against an approved-group catalogue, submits valid rows to GIAM via the existing `lrp` CLI (one recipient at a time, using `--on-behalf-of`), and writes a status report plus a retry file for anything that failed.

**Architecture:** A small package (`bulkprovision/`) with one module per responsibility — Excel I/O, validation, an `lrp` CLI wrapper, per-recipient orchestration, and reporting — wired together by a thin CLI entry point. The `lrp` wrapper and orchestration both accept a `client` object so tests never shell out to the real `lrp` binary. The entry point also ensures `lrp` itself is installed (auto-installing via the official install script if missing) and checks authentication before doing anything else.

**Tech Stack:** Python 3.12 (already installed), `openpyxl` 3.1.5 (already installed) for `.xlsx` I/O, `pytest` 9.0.3 (already installed) for tests. No other dependencies — stdlib `subprocess`, `csv`, `json`, `argparse`, `shutil`.

**Spec:** `docs/superpowers/specs/2026-08-17-giam-bulk-access-automation-design.md`

## Global Constraints

- Runs locally per operator, authenticated via that operator's own `lrp login` session — never a shared TU account (spec Section 5, Section 8).
- `lrp login` itself is never automated (it requires a human completing real SSO in a browser) — this tool only auto-installs the `lrp` binary and checks whether a session already exists.
- `submit-cart` responses with `result: "warning"` (partial success / already-assigned duplicates) must be reported as `warning`, never conflated with `error` (spec Section 7).
- Every `error` row must carry a human-readable reason string (spec Section 2, acceptance criteria).
- Failed (`error`) rows must be retriable from a stored file without re-supplying the original Excel (spec Section 2, acceptance criteria).
- No LLM/AI step anywhere in this pipeline — pure deterministic code (spec Section 4).
- Recipients are identified by whatever `lrp find-user` accepts (email, name, or ID) — not strictly a BID, since real test recipients are emails.

---

## File Structure

```
azgiam-onboarding/
  bulkprovision/
    __init__.py
    io_excel.py        # InputRow, read_input_rows(), read_catalogue_groups()
    validation.py       # ValidationResult, validate_rows()
    lrp_client.py        # LrpError, check_auth(), find_user(), search_product(),
                         # add_to_cart(), get_cart(), submit_cart(), list_orders()
    bootstrap.py         # ensure_lrp_installed()
    orchestrator.py      # RowResult, humanize(), process_recipient(), process_all()
    report.py            # write_report(), write_retry_store(), read_retry_rows()
    cli.py                # main(argv, client, ensure_installed) - entry point
  tests/
    test_io_excel.py
    test_validation.py
    test_lrp_client.py
    test_bootstrap.py
    test_orchestrator.py
    test_report.py
    test_cli.py
  samples/
    input.xlsx            # real test recipients supplied by the user
    catalogue.xlsx         # placeholder approved-group catalogue
  requirements.txt
```

---

### Task 1: Excel I/O

**Files:**
- Create: `bulkprovision/__init__.py` (empty)
- Create: `bulkprovision/io_excel.py`
- Test: `tests/test_io_excel.py`

**Interfaces:**
- Produces: `InputRow` dataclass (`recipient: str`, `giam_group: str`, `justification: str`); `read_input_rows(path) -> list[InputRow]`; `read_catalogue_groups(path) -> set[str]`.

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_io_excel.py
import openpyxl
import pytest

from bulkprovision.io_excel import read_input_rows, read_catalogue_groups, InputRow


def _write_workbook(path, header, rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(header)
    for row in rows:
        ws.append(row)
    wb.save(path)


def test_read_input_rows_parses_valid_rows(tmp_path):
    path = tmp_path / "input.xlsx"
    _write_workbook(
        path,
        ["recipient", "giam_group", "justification"],
        [
            ["extern.asthana_ankit@allianz.de", "APP-GITHUB-ADMIN", "Onboarding"],
            ["sachin.lakhpati@allianz.com", "APP-GITHUB-READ", "Onboarding"],
        ],
    )
    rows = read_input_rows(path)
    assert rows == [
        InputRow(recipient="extern.asthana_ankit@allianz.de", giam_group="APP-GITHUB-ADMIN", justification="Onboarding"),
        InputRow(recipient="sachin.lakhpati@allianz.com", giam_group="APP-GITHUB-READ", justification="Onboarding"),
    ]


def test_read_input_rows_skips_blank_rows(tmp_path):
    path = tmp_path / "input.xlsx"
    _write_workbook(
        path,
        ["recipient", "giam_group", "justification"],
        [
            ["extern.asthana_ankit@allianz.de", "APP-GITHUB-ADMIN", "Onboarding"],
            [None, None, None],
        ],
    )
    rows = read_input_rows(path)
    assert len(rows) == 1


def test_read_input_rows_missing_column_raises(tmp_path):
    path = tmp_path / "input.xlsx"
    _write_workbook(path, ["recipient", "justification"], [["a@b.com", "Onboarding"]])
    with pytest.raises(ValueError, match="recipient, giam_group, justification"):
        read_input_rows(path)


def test_read_catalogue_groups_returns_set(tmp_path):
    path = tmp_path / "catalogue.xlsx"
    _write_workbook(path, ["giam_group"], [["APP-GITHUB-ADMIN"], ["APP-GITHUB-READ"]])
    groups = read_catalogue_groups(path)
    assert groups == {"APP-GITHUB-ADMIN", "APP-GITHUB-READ"}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd /home/luser/projects/git_repo/azgiam-onboarding && python3 -m pytest tests/test_io_excel.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'bulkprovision'`

- [ ] **Step 3: Write minimal implementation**

```python
# bulkprovision/io_excel.py
"""Read input and catalogue rows from Excel files."""
from dataclasses import dataclass

import openpyxl


@dataclass
class InputRow:
    recipient: str
    giam_group: str
    justification: str


def read_input_rows(path):
    """Read (recipient, giam_group, justification) rows from an input Excel file.

    Expects a header row with columns named exactly: recipient, giam_group,
    justification (case-insensitive, any column order).
    """
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    sheet = wb.active
    rows_iter = sheet.iter_rows(values_only=True)
    header = [str(h).strip().lower() if h is not None else "" for h in next(rows_iter)]
    try:
        recipient_idx = header.index("recipient")
        group_idx = header.index("giam_group")
        just_idx = header.index("justification")
    except ValueError as exc:
        raise ValueError(
            f"Input Excel must have columns: recipient, giam_group, justification. Found: {header}"
        ) from exc

    result = []
    for row in rows_iter:
        if row is None or all(cell is None for cell in row):
            continue
        recipient = str(row[recipient_idx]).strip() if row[recipient_idx] is not None else ""
        group = str(row[group_idx]).strip() if row[group_idx] is not None else ""
        justification = str(row[just_idx]).strip() if row[just_idx] is not None else ""
        if not recipient or not group:
            continue
        result.append(InputRow(recipient=recipient, giam_group=group, justification=justification))
    return result


def read_catalogue_groups(path):
    """Read the set of approved GIAM group names from a catalogue Excel file.

    Expects a header row with a column named exactly: giam_group
    (case-insensitive).
    """
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    sheet = wb.active
    rows_iter = sheet.iter_rows(values_only=True)
    header = [str(h).strip().lower() if h is not None else "" for h in next(rows_iter)]
    try:
        group_idx = header.index("giam_group")
    except ValueError as exc:
        raise ValueError(f"Catalogue Excel must have a column: giam_group. Found: {header}") from exc

    groups = set()
    for row in rows_iter:
        if row is None or row[group_idx] is None:
            continue
        value = str(row[group_idx]).strip()
        if value:
            groups.add(value)
    return groups
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_io_excel.py -v`
Expected: PASS (4 tests)

- [ ] **Step 5: Commit**

```bash
git add bulkprovision/__init__.py bulkprovision/io_excel.py tests/test_io_excel.py
git commit -m "Add Excel I/O for bulk provisioning input and catalogue files"
```

---

### Task 2: Validation Engine

**Files:**
- Create: `bulkprovision/validation.py`
- Test: `tests/test_validation.py`

**Interfaces:**
- Consumes: `InputRow` (Task 1).
- Produces: `ValidationResult` dataclass (`valid: list[InputRow]`, `invalid: list[tuple[InputRow, str]]`); `validate_rows(input_rows, catalogue_groups) -> ValidationResult`.

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_validation.py
from bulkprovision.io_excel import InputRow
from bulkprovision.validation import validate_rows


def test_validate_rows_splits_valid_and_invalid():
    rows = [
        InputRow(recipient="a@b.com", giam_group="APP-GITHUB-ADMIN", justification="x"),
        InputRow(recipient="b@b.com", giam_group="APP-UNKNOWN-ROLE", justification="x"),
    ]
    catalogue = {"APP-GITHUB-ADMIN", "APP-GITHUB-READ"}

    result = validate_rows(rows, catalogue)

    assert result.valid == [rows[0]]
    assert len(result.invalid) == 1
    assert result.invalid[0][0] == rows[1]
    assert "not found in approved GIAM group catalogue" in result.invalid[0][1]


def test_validate_rows_is_case_and_whitespace_insensitive():
    rows = [InputRow(recipient="a@b.com", giam_group="  app-github-admin ", justification="x")]
    catalogue = {"APP-GITHUB-ADMIN"}

    result = validate_rows(rows, catalogue)

    assert result.valid == rows
    assert result.invalid == []
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python3 -m pytest tests/test_validation.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'bulkprovision.validation'`

- [ ] **Step 3: Write minimal implementation**

```python
# bulkprovision/validation.py
"""Validate input rows against the approved GIAM group catalogue."""
from dataclasses import dataclass


@dataclass
class ValidationResult:
    valid: list
    invalid: list


def validate_rows(input_rows, catalogue_groups):
    """Split input rows into valid/invalid based on the catalogue.

    A row is valid only if its giam_group matches a catalogue entry exactly
    (case-insensitive, whitespace-trimmed). Invalid rows carry a reason
    string explaining why.
    """
    normalized_catalogue = {g.strip().lower() for g in catalogue_groups}

    valid = []
    invalid = []
    for row in input_rows:
        key = row.giam_group.strip().lower()
        if key in normalized_catalogue:
            valid.append(row)
        else:
            invalid.append((row, f"'{row.giam_group}' not found in approved GIAM group catalogue"))
    return ValidationResult(valid=valid, invalid=invalid)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_validation.py -v`
Expected: PASS (2 tests)

- [ ] **Step 5: Commit**

```bash
git add bulkprovision/validation.py tests/test_validation.py
git commit -m "Add validation engine for GIAM group catalogue checks"
```

---

### Task 3: LRP CLI Wrapper

**Files:**
- Create: `bulkprovision/lrp_client.py`
- Test: `tests/test_lrp_client.py`

**Interfaces:**
- Produces: `LrpError(code, message)` exception; `check_auth() -> bool`; `find_user(recipient) -> dict`; `search_product(group_name) -> dict`; `add_to_cart(products: list[dict]) -> dict`; `get_cart() -> dict`; `submit_cart(items, reason, on_behalf_of) -> dict`; `list_orders() -> list[dict]`.

Exact JSON shapes below were confirmed by reading `lrp-cli`'s Go source directly (`cmd/find_user.go`, `cmd/search_products.go`, `cmd/get_cart.go`, `cmd/list_orders.go`, `cmd/order_response_test.go`), not guessed:
- `find-user`: `{"total": int, "items": [{"id", "name", "email"}]}`
- `search-products`: `{"total": int, "products": [{"productId", "shopIdPath", "name", "description", "sourceName", "sourceOidServer", "serviceCategory", "id"}]}`
- `get-cart`: `{"total": int, "items": [{"cartItemId", "productId", "name", ...}], "error": bool}`
- `submit-cart`: `{"result": "success"|"warning"|"error", "message": "<KEY>", "nonRequestableProducts": {"<centralAccount>": [{"name": "..."}]}}`
- `list-orders`: `{"total": int, "productRequests": [{"requestKey", "status", ...}], "error": bool}`
- CLI-level errors (auth/HTTP/connection, from any command): `{"error": true, "code": "...", "message": "..."}`

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_lrp_client.py
import json
from unittest.mock import patch, MagicMock

import pytest

from bulkprovision.lrp_client import (
    check_auth, find_user, search_product, add_to_cart, get_cart,
    submit_cart, list_orders, LrpError,
)


def _mock_completed(stdout_obj, stderr="", returncode=0):
    completed = MagicMock()
    completed.stdout = json.dumps(stdout_obj)
    completed.stderr = stderr
    completed.returncode = returncode
    return completed


@patch("bulkprovision.lrp_client.subprocess.run")
def test_check_auth_true_on_exit_zero(mock_run):
    mock_run.return_value = MagicMock(returncode=0)
    assert check_auth() is True
    mock_run.assert_called_once_with(["lrp", "check-auth"], capture_output=True, text=True)


@patch("bulkprovision.lrp_client.subprocess.run")
def test_check_auth_false_on_nonzero_exit(mock_run):
    mock_run.return_value = MagicMock(returncode=1)
    assert check_auth() is False


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_returns_single_match(mock_run):
    mock_run.return_value = _mock_completed({
        "total": 1,
        "items": [{"id": "x1", "name": "Asthana, Ankit", "email": "extern.asthana_ankit@allianz.de"}],
    })
    user = find_user("extern.asthana_ankit@allianz.de")
    assert user["id"] == "x1"
    mock_run.assert_called_once_with(
        ["lrp", "find-user", "extern.asthana_ankit@allianz.de", "-o", "json"],
        capture_output=True, text=True,
    )


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_raises_on_zero_matches(mock_run):
    mock_run.return_value = _mock_completed({"total": 0, "items": []})
    with pytest.raises(LrpError, match="USER_NOT_FOUND"):
        find_user("unknown@allianz.de")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_raises_on_multiple_matches(mock_run):
    mock_run.return_value = _mock_completed({"total": 2, "items": [{"id": "x1"}, {"id": "x2"}]})
    with pytest.raises(LrpError, match="AMBIGUOUS_USER"):
        find_user("common-name")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_search_product_matches_by_exact_name(mock_run):
    mock_run.return_value = _mock_completed({
        "total": 2,
        "products": [
            {"productId": "CCC-1", "name": "APP-GITHUB-ADMIN"},
            {"productId": "CCC-2", "name": "APP-GITHUB-READ"},
        ],
    })
    product = search_product("APP-GITHUB-ADMIN")
    assert product["productId"] == "CCC-1"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_search_product_raises_when_no_exact_match(mock_run):
    mock_run.return_value = _mock_completed({"total": 1, "products": [{"productId": "CCC-1", "name": "APP-OTHER"}]})
    with pytest.raises(LrpError, match="PRODUCT_NOT_FOUND"):
        search_product("APP-GITHUB-ADMIN")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_run_raises_lrp_error_on_error_envelope(mock_run):
    mock_run.return_value = _mock_completed({"error": True, "code": "AUTH_EXPIRED", "message": "Session expired."})
    with pytest.raises(LrpError, match="AUTH_EXPIRED"):
        find_user("extern.asthana_ankit@allianz.de")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_add_to_cart_forces_is_added_to_cart_false(mock_run):
    mock_run.return_value = _mock_completed({"total": 1, "items": []})
    add_to_cart([{"productId": "CCC-1", "name": "APP-GITHUB-ADMIN", "isAddedToCart": True}])
    called_args = mock_run.call_args[0][0]
    products_json = called_args[called_args.index("--products") + 1]
    assert json.loads(products_json)[0]["isAddedToCart"] is False


@patch("bulkprovision.lrp_client.subprocess.run")
def test_get_cart_returns_items(mock_run):
    mock_run.return_value = _mock_completed({"total": 1, "items": [{"cartItemId": "1"}], "error": False})
    cart = get_cart()
    assert cart["items"][0]["cartItemId"] == "1"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_submit_cart_passes_through_warning_result_without_raising(mock_run):
    mock_run.return_value = _mock_completed({
        "result": "warning",
        "message": "WARNING_ONE_ON_BEHALF_SOME_DUPLICATES",
        "nonRequestableProducts": {"Z4QTV6A": [{"name": "APP-GITHUB-READ"}]},
    })
    response = submit_cart(items=[{"cartItemId": "1"}], reason="Onboarding", on_behalf_of={"id": "u1"})
    assert response["result"] == "warning"
    assert response["nonRequestableProducts"]["Z4QTV6A"][0]["name"] == "APP-GITHUB-READ"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_submit_cart_returns_error_result_without_raising(mock_run):
    mock_run.return_value = _mock_completed({"result": "error", "message": "ERROR_ORDER_FAILED"})
    response = submit_cart(items=[{"cartItemId": "1"}], reason="x", on_behalf_of={"id": "u1"})
    assert response["result"] == "error"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_list_orders_returns_product_requests(mock_run):
    mock_run.return_value = _mock_completed({
        "total": 1, "productRequests": [{"requestKey": "r1", "status": "Pending"}], "error": False,
    })
    orders = list_orders()
    assert orders[0]["status"] == "Pending"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python3 -m pytest tests/test_lrp_client.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'bulkprovision.lrp_client'`

- [ ] **Step 3: Write minimal implementation**

```python
# bulkprovision/lrp_client.py
"""Thin wrapper around the `lrp` CLI: JSON in, JSON out, errors as exceptions."""
import json
import subprocess


class LrpError(Exception):
    def __init__(self, code, message):
        self.code = code
        self.message = message
        super().__init__(f"{code}: {message}")


def check_auth():
    """Return True if the current lrp session is authenticated."""
    completed = subprocess.run(["lrp", "check-auth"], capture_output=True, text=True)
    return completed.returncode == 0


def _run(args):
    """Run `lrp <args> -o json` and return the parsed JSON response.

    Raises LrpError if the CLI signals a top-level error via
    {"error": true, "code", "message"} - this covers auth/HTTP/connection
    failures uniformly across every command.
    """
    completed = subprocess.run(["lrp", *args, "-o", "json"], capture_output=True, text=True)
    stdout = completed.stdout.strip()
    if not stdout:
        raise LrpError("NO_OUTPUT", completed.stderr.strip() or "lrp produced no output")

    data = json.loads(stdout)
    if isinstance(data, dict) and data.get("error") is True:
        raise LrpError(data.get("code", "UNKNOWN_ERROR"), data.get("message", "lrp reported an error"))
    return data


def find_user(recipient):
    """Return the single matching user object for a recipient (email, name,
    or ID), or raise LrpError if zero or multiple matches are found."""
    data = _run(["find-user", recipient])
    items = data.get("items", [])
    if len(items) != 1:
        raise LrpError(
            "AMBIGUOUS_USER" if len(items) > 1 else "USER_NOT_FOUND",
            f"Expected exactly one match for '{recipient}', found {len(items)}",
        )
    return items[0]


def search_product(group_name):
    """Return the single product object matching a GIAM group name exactly
    (case-insensitive), or raise LrpError if not found or ambiguous."""
    data = _run(["search-products", group_name])
    products = data.get("products", [])
    matches = [p for p in products if p.get("name", "").strip().lower() == group_name.strip().lower()]
    if len(matches) != 1:
        raise LrpError(
            "PRODUCT_NOT_FOUND",
            f"Expected exactly one exact match for '{group_name}', found {len(matches)}",
        )
    return matches[0]


def add_to_cart(products):
    """Add product objects (as returned by search_product) to the cart."""
    payload = [{**p, "isAddedToCart": False} for p in products]
    return _run(["add-to-cart", "--products", json.dumps(payload)])


def get_cart():
    """Return the current cart contents."""
    return _run(["get-cart"])


def submit_cart(items, reason, on_behalf_of):
    """Submit cart items on behalf of a user. Returns the parsed response,
    which always has 'result' ('success'|'warning'|'error') and 'message'.
    Does not raise on 'warning'/'error' result - callers inspect it."""
    return _run([
        "submit-cart",
        "--items", json.dumps(items),
        "--reason", reason,
        "--on-behalf-of", json.dumps(on_behalf_of),
    ])


def list_orders():
    """Return the list of orders for the current session's account."""
    data = _run(["list-orders"])
    return data.get("productRequests", [])
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_lrp_client.py -v`
Expected: PASS (12 tests)

- [ ] **Step 5: Commit**

```bash
git add bulkprovision/lrp_client.py tests/test_lrp_client.py
git commit -m "Add lrp CLI wrapper with confirmed JSON response shapes"
```

---

### Task 4: Auto-Install Bootstrap

**Files:**
- Create: `bulkprovision/bootstrap.py`
- Test: `tests/test_bootstrap.py`

**Interfaces:**
- Produces: `ensure_lrp_installed(run=subprocess.run, which=shutil.which) -> bool`.

Safety note: this only ever runs the official install script already documented in `lrp-cli/README.md` (`curl -fsSL <artifactory-url> | sh`), from the project's own trusted Artifactory host — no arbitrary or user-supplied URL, and it never touches `lrp login`/credentials.

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_bootstrap.py
from unittest.mock import MagicMock

from bulkprovision.bootstrap import ensure_lrp_installed, INSTALL_SCRIPT_URL


def test_ensure_lrp_installed_skips_install_when_already_present():
    which = MagicMock(return_value="/home/user/.local/bin/lrp")
    run = MagicMock()

    result = ensure_lrp_installed(run=run, which=which)

    assert result is True
    run.assert_not_called()


def test_ensure_lrp_installed_runs_install_script_when_missing():
    which = MagicMock(side_effect=[None, "/home/user/.local/bin/lrp"])
    run = MagicMock(return_value=MagicMock(returncode=0))

    result = ensure_lrp_installed(run=run, which=which)

    assert result is True
    run.assert_called_once()
    command = run.call_args[0][0]
    assert INSTALL_SCRIPT_URL in command


def test_ensure_lrp_installed_returns_false_when_install_fails():
    which = MagicMock(return_value=None)
    run = MagicMock(return_value=MagicMock(returncode=1))

    result = ensure_lrp_installed(run=run, which=which)

    assert result is False
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python3 -m pytest tests/test_bootstrap.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'bulkprovision.bootstrap'`

- [ ] **Step 3: Write minimal implementation**

```python
# bulkprovision/bootstrap.py
"""Ensure the `lrp` CLI is installed before running a batch."""
import shutil
import subprocess

# Official install script from lrp-cli/README.md - internal Artifactory host.
INSTALL_SCRIPT_URL = "https://artifactory.prod.de.enablingtools.allianz/artifactory/static-release-local/gdc/lrp-cli/v0.0.17/install.sh"


def ensure_lrp_installed(run=subprocess.run, which=shutil.which):
    """Return True if `lrp` is on PATH after this call, installing it via
    the official install script first if it wasn't already present."""
    if which("lrp") is not None:
        return True

    result = run(f"curl -fsSL {INSTALL_SCRIPT_URL} | sh", shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        return False
    return which("lrp") is not None
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_bootstrap.py -v`
Expected: PASS (3 tests)

- [ ] **Step 5: Commit**

```bash
git add bulkprovision/bootstrap.py tests/test_bootstrap.py
git commit -m "Add auto-install bootstrap for the lrp CLI"
```

---

### Task 5: Per-Recipient Orchestration

**Files:**
- Create: `bulkprovision/orchestrator.py`
- Test: `tests/test_orchestrator.py`

**Interfaces:**
- Consumes: `InputRow` (Task 1); `LrpError`, and the `lrp_client` function set (Task 3) via a duck-typed `client` object with methods `find_user`, `search_product`, `add_to_cart`, `get_cart`, `submit_cart`.
- Produces: `RowResult` dataclass (`recipient: str`, `giam_group: str`, `status: str`, `message: str`); `humanize(message_key) -> str`; `process_recipient(recipient, rows, client) -> list[RowResult]`; `process_all(valid_rows, client) -> list[RowResult]`.

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_orchestrator.py
from bulkprovision.io_excel import InputRow
from bulkprovision.lrp_client import LrpError
from bulkprovision.orchestrator import RowResult, humanize, process_recipient, process_all


class FakeClient:
    def __init__(self):
        self.user = {"id": "u1", "name": "Asthana, Ankit", "email": "extern.asthana_ankit@allianz.de"}
        self.products = {
            "APP-GITHUB-ADMIN": {"productId": "CCC-1", "name": "APP-GITHUB-ADMIN"},
            "APP-GITHUB-READ": {"productId": "CCC-2", "name": "APP-GITHUB-READ"},
        }
        self.submit_response = {"result": "success", "message": "SUCCESS"}
        self.cart_items = [{"cartItemId": "1"}, {"cartItemId": "2"}]
        self.submitted_items = None

    def find_user(self, recipient):
        return self.user

    def search_product(self, group_name):
        return self.products[group_name]

    def add_to_cart(self, products):
        return {"total": len(products), "items": []}

    def get_cart(self):
        return {"total": len(self.cart_items), "items": self.cart_items}

    def submit_cart(self, items, reason, on_behalf_of):
        self.submitted_items = items
        return self.submit_response


def test_process_recipient_submits_all_valid_groups():
    rows = [
        InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="Onboarding"),
        InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="Onboarding"),
    ]
    client = FakeClient()

    results = process_recipient("Q1", rows, client=client)

    assert len(results) == 2
    assert all(r.status == "submitted" for r in results)
    assert client.submitted_items == client.cart_items


def test_process_recipient_marks_error_when_user_not_found():
    rows = [InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x")]
    client = FakeClient()

    def raise_not_found(recipient):
        raise LrpError("USER_NOT_FOUND", "no match")

    client.find_user = raise_not_found

    results = process_recipient("Q1", rows, client=client)

    assert results == [RowResult("Q1", "APP-GITHUB-ADMIN", "error", "no match")]


def test_process_recipient_marks_error_for_missing_product_but_continues_others():
    rows = [
        InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x"),
        InputRow(recipient="Q1", giam_group="APP-UNKNOWN", justification="x"),
    ]
    client = FakeClient()

    def search(group_name):
        if group_name not in client.products:
            raise LrpError("PRODUCT_NOT_FOUND", f"'{group_name}' not found")
        return client.products[group_name]

    client.search_product = search

    results = process_recipient("Q1", rows, client=client)

    by_group = {r.giam_group: r for r in results}
    assert by_group["APP-GITHUB-ADMIN"].status == "submitted"
    assert by_group["APP-UNKNOWN"].status == "error"
    assert "not found" in by_group["APP-UNKNOWN"].message


def test_process_recipient_flags_warning_for_non_requestable_products():
    rows = [InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="x")]
    client = FakeClient()
    client.submit_response = {
        "result": "warning",
        "message": "WARNING_ONE_ON_BEHALF_SOME_DUPLICATES",
        "nonRequestableProducts": {"Z4QTV6A": [{"name": "APP-GITHUB-READ"}]},
    }

    results = process_recipient("Q1", rows, client=client)

    assert results[0].status == "warning"
    assert "already assigned or requested" in results[0].message


def test_process_all_groups_by_recipient():
    rows = [
        InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x"),
        InputRow(recipient="Q2", giam_group="APP-GITHUB-READ", justification="x"),
    ]
    client = FakeClient()

    results = process_all(rows, client=client)

    assert {r.recipient for r in results} == {"Q1", "Q2"}


def test_humanize_known_key_and_fallback():
    assert humanize("SUCCESS") == "Order submitted successfully."
    assert humanize("SOME_NEW_KEY") == "SOME_NEW_KEY"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python3 -m pytest tests/test_orchestrator.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'bulkprovision.orchestrator'`

- [ ] **Step 3: Write minimal implementation**

```python
# bulkprovision/orchestrator.py
"""Coordinate validated input rows through the lrp CLI, per recipient."""
from dataclasses import dataclass

from bulkprovision.lrp_client import LrpError

# Mirrors lrp-cli's cmd/order_messages.go so reports read the same sentences
# a human running `lrp` directly would see.
RESULT_MESSAGES = {
    "SUCCESS": "Order submitted successfully.",
    "ERROR_ONE_ON_BEHALF_DUPLICATE": "The recipient already has (or has already requested) this product.",
    "ERROR_ONE_ON_BEHALF_ALL_DUPLICATES": "The recipient already has (or has already requested) all of these products.",
    "WARNING_ONE_ON_BEHALF_SOME_DUPLICATES": "Some products were already assigned or requested for the recipient; the rest were ordered.",
    "WARNING_SOME_ON_BEHALF_DUPLICATE": "Some recipients already had this product and were skipped; the rest were ordered.",
    "ERROR_ORDER_FAILED": "The order could not be submitted.",
    "ERROR_UNKNOWN": "The order failed for an unknown reason.",
}


def humanize(message_key):
    return RESULT_MESSAGES.get(message_key, message_key)


@dataclass
class RowResult:
    recipient: str
    giam_group: str
    status: str
    message: str


def _flatten_skipped_product_names(non_requestable):
    names = set()
    for products in non_requestable.values():
        for product in products:
            name = product.get("name")
            if name:
                names.add(name)
    return names


def process_recipient(recipient, rows, client):
    """Process all valid rows for a single recipient. Returns one RowResult
    per input row. Never raises - lrp_client errors become status='error'."""
    try:
        user = client.find_user(recipient)
    except LrpError as exc:
        return [RowResult(recipient, row.giam_group, "error", exc.message) for row in rows]

    products_by_group = {}
    results = []
    for row in rows:
        try:
            products_by_group[row.giam_group] = client.search_product(row.giam_group)
        except LrpError as exc:
            results.append(RowResult(recipient, row.giam_group, "error", exc.message))

    orderable_rows = [row for row in rows if row.giam_group in products_by_group]
    if not orderable_rows:
        return results

    try:
        client.add_to_cart(list(products_by_group.values()))
        cart = client.get_cart()
        reason = orderable_rows[0].justification or "Bulk onboarding access request"
        submit_response = client.submit_cart(cart.get("items", []), reason, user)
    except LrpError as exc:
        for row in orderable_rows:
            results.append(RowResult(recipient, row.giam_group, "error", exc.message))
        return results

    result_kind = submit_response.get("result", "error")
    message = humanize(submit_response.get("message", ""))
    non_requestable = submit_response.get("nonRequestableProducts") or {}
    skipped_names = _flatten_skipped_product_names(non_requestable)

    for row in orderable_rows:
        product_name = products_by_group[row.giam_group].get("name", row.giam_group)
        if result_kind == "error":
            results.append(RowResult(recipient, row.giam_group, "error", message))
        elif product_name in skipped_names:
            results.append(RowResult(recipient, row.giam_group, "warning", message))
        else:
            results.append(RowResult(recipient, row.giam_group, "submitted", message))
    return results


def process_all(valid_rows, client):
    """Process all valid rows, grouped by recipient, one recipient fully
    completed before the next starts. Returns a flat list of RowResult."""
    rows_by_recipient = {}
    for row in valid_rows:
        rows_by_recipient.setdefault(row.recipient, []).append(row)

    all_results = []
    for recipient, rows in rows_by_recipient.items():
        all_results.extend(process_recipient(recipient, rows, client))
    return all_results
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_orchestrator.py -v`
Expected: PASS (6 tests)

- [ ] **Step 5: Commit**

```bash
git add bulkprovision/orchestrator.py tests/test_orchestrator.py
git commit -m "Add per-recipient orchestration of lrp CLI calls"
```

---

### Task 6: Report and Retry Store

**Files:**
- Create: `bulkprovision/report.py`
- Test: `tests/test_report.py`

**Interfaces:**
- Consumes: `RowResult` (Task 5).
- Produces: `write_report(results, path)`; `write_retry_store(results, path, run_id)`; `read_retry_rows(path) -> list[dict]` (each dict has keys `recipient`, `giam_group`, `reason`).

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_report.py
import csv
import json

from bulkprovision.orchestrator import RowResult
from bulkprovision.report import write_report, write_retry_store, read_retry_rows


def test_write_report_writes_one_row_per_result(tmp_path):
    results = [
        RowResult("extern.asthana_ankit@allianz.de", "APP-GITHUB-ADMIN", "submitted", "Order submitted successfully."),
        RowResult("sachin.lakhpati@allianz.com", "APP-UNKNOWN", "rejected", "not in catalogue"),
    ]
    path = tmp_path / "report.csv"

    write_report(results, path)

    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    assert rows == [
        {"recipient": "extern.asthana_ankit@allianz.de", "giam_group": "APP-GITHUB-ADMIN", "status": "submitted", "message": "Order submitted successfully."},
        {"recipient": "sachin.lakhpati@allianz.com", "giam_group": "APP-UNKNOWN", "status": "rejected", "message": "not in catalogue"},
    ]


def test_write_retry_store_only_includes_error_rows(tmp_path):
    results = [
        RowResult("a@b.com", "APP-GITHUB-ADMIN", "submitted", "ok"),
        RowResult("b@b.com", "APP-UNKNOWN", "error", "boom"),
    ]
    path = tmp_path / "retry.json"

    write_retry_store(results, path, run_id="run-1")

    payload = json.loads(path.read_text())
    assert payload["run_id"] == "run-1"
    assert payload["rows"] == [{"recipient": "b@b.com", "giam_group": "APP-UNKNOWN", "reason": "boom"}]


def test_read_retry_rows_returns_empty_list_when_missing(tmp_path):
    assert read_retry_rows(tmp_path / "missing.json") == []


def test_read_retry_rows_round_trips(tmp_path):
    results = [RowResult("a@b.com", "APP-GITHUB-ADMIN", "error", "boom")]
    path = tmp_path / "retry.json"
    write_retry_store(results, path, run_id="run-1")

    rows = read_retry_rows(path)

    assert rows == [{"recipient": "a@b.com", "giam_group": "APP-GITHUB-ADMIN", "reason": "boom"}]
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python3 -m pytest tests/test_report.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'bulkprovision.report'`

- [ ] **Step 3: Write minimal implementation**

```python
# bulkprovision/report.py
"""Write per-run status reports and a retry store for failed rows."""
import csv
import json
from pathlib import Path


def write_report(results, path):
    """Write one row per RowResult to a CSV report."""
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["recipient", "giam_group", "status", "message"])
        for r in results:
            writer.writerow([r.recipient, r.giam_group, r.status, r.message])


def write_retry_store(results, path, run_id):
    """Write rows with status 'error' to a JSON retry file, keyed by run_id."""
    retryable = [
        {"recipient": r.recipient, "giam_group": r.giam_group, "reason": r.message}
        for r in results if r.status == "error"
    ]
    Path(path).write_text(json.dumps({"run_id": run_id, "rows": retryable}, indent=2))


def read_retry_rows(path):
    """Read rows from a retry store file. Returns [] if the file doesn't exist."""
    p = Path(path)
    if not p.exists():
        return []
    return json.loads(p.read_text()).get("rows", [])
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_report.py -v`
Expected: PASS (4 tests)

- [ ] **Step 5: Commit**

```bash
git add bulkprovision/report.py tests/test_report.py
git commit -m "Add status report and retry store for bulk provisioning runs"
```

---

### Task 7: CLI Entry Point

**Files:**
- Create: `bulkprovision/cli.py`
- Test: `tests/test_cli.py`

**Interfaces:**
- Consumes: everything from Tasks 1-6.
- Produces: `main(argv=None, client=<lrp_client module>, ensure_installed=ensure_lrp_installed) -> int` (exit code: `0` clean, `1` some rows errored, `2` not authenticated, `3` lrp install failed).

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_cli.py
import csv
import json

import openpyxl

from bulkprovision.cli import main
from bulkprovision.lrp_client import LrpError


def _write_workbook(path, header, rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(header)
    for row in rows:
        ws.append(row)
    wb.save(path)


class FakeClient:
    def check_auth(self):
        return True

    def find_user(self, recipient):
        return {"id": "u1", "name": "Test User", "email": recipient}

    def search_product(self, group_name):
        return {"productId": "CCC-1", "name": group_name}

    def add_to_cart(self, products):
        return {"total": len(products), "items": []}

    def get_cart(self):
        return {"total": 1, "items": [{"cartItemId": "1"}]}

    def submit_cart(self, items, reason, on_behalf_of):
        return {"result": "success", "message": "SUCCESS"}


def _args(tmp_path, input_path, catalogue_path, run_id="run-1"):
    return [
        "--input", str(input_path),
        "--catalogue", str(catalogue_path),
        "--report", str(tmp_path / "report.csv"),
        "--retry-out", str(tmp_path / "retry.json"),
        "--run-id", run_id,
    ]


def test_main_end_to_end_writes_report_and_retry_store(tmp_path):
    input_path = tmp_path / "input.xlsx"
    catalogue_path = tmp_path / "catalogue.xlsx"
    _write_workbook(
        input_path,
        ["recipient", "giam_group", "justification"],
        [
            ["extern.asthana_ankit@allianz.de", "APP-GITHUB-ADMIN", "Onboarding"],
            ["extern.asthana_ankit@allianz.de", "APP-NOT-APPROVED", "Onboarding"],
        ],
    )
    _write_workbook(catalogue_path, ["giam_group"], [["APP-GITHUB-ADMIN"]])

    exit_code = main(
        _args(tmp_path, input_path, catalogue_path),
        client=FakeClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 0
    with open(tmp_path / "report.csv", newline="") as f:
        rows = list(csv.DictReader(f))
    statuses = {(r["giam_group"], r["status"]) for r in rows}
    assert ("APP-GITHUB-ADMIN", "submitted") in statuses
    assert ("APP-NOT-APPROVED", "rejected") in statuses

    retry_payload = json.loads((tmp_path / "retry.json").read_text())
    assert retry_payload["run_id"] == "run-1"
    assert retry_payload["rows"] == []


def test_main_returns_exit_code_1_when_errors_occur(tmp_path):
    input_path = tmp_path / "input.xlsx"
    catalogue_path = tmp_path / "catalogue.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])
    _write_workbook(catalogue_path, ["giam_group"], [["APP-GITHUB-ADMIN"]])

    class ErroringClient(FakeClient):
        def find_user(self, recipient):
            raise LrpError("USER_NOT_FOUND", "no match")

    exit_code = main(
        _args(tmp_path, input_path, catalogue_path, run_id="run-2"),
        client=ErroringClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 1
    retry_payload = json.loads((tmp_path / "retry.json").read_text())
    assert retry_payload["rows"] == [{"recipient": "a@b.com", "giam_group": "APP-GITHUB-ADMIN", "reason": "no match"}]


def test_main_returns_exit_code_2_when_not_authenticated(tmp_path):
    input_path = tmp_path / "input.xlsx"
    catalogue_path = tmp_path / "catalogue.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])
    _write_workbook(catalogue_path, ["giam_group"], [["APP-GITHUB-ADMIN"]])

    class NotAuthedClient(FakeClient):
        def check_auth(self):
            return False

    exit_code = main(
        _args(tmp_path, input_path, catalogue_path, run_id="run-3"),
        client=NotAuthedClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 2
    assert not (tmp_path / "report.csv").exists()


def test_main_returns_exit_code_3_when_lrp_not_installed(tmp_path):
    input_path = tmp_path / "input.xlsx"
    catalogue_path = tmp_path / "catalogue.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])
    _write_workbook(catalogue_path, ["giam_group"], [["APP-GITHUB-ADMIN"]])

    exit_code = main(
        _args(tmp_path, input_path, catalogue_path, run_id="run-4"),
        client=FakeClient(),
        ensure_installed=lambda: False,
    )

    assert exit_code == 3
    assert not (tmp_path / "report.csv").exists()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `python3 -m pytest tests/test_cli.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'bulkprovision.cli'`

- [ ] **Step 3: Write minimal implementation**

```python
# bulkprovision/cli.py
"""Entry point: ensure lrp is installed, check auth, validate, submit, report."""
import argparse
import sys

from bulkprovision import lrp_client as default_client
from bulkprovision.bootstrap import ensure_lrp_installed
from bulkprovision.io_excel import read_input_rows, read_catalogue_groups
from bulkprovision.validation import validate_rows
from bulkprovision.orchestrator import process_all, RowResult
from bulkprovision.report import write_report, write_retry_store


def main(argv=None, client=default_client, ensure_installed=ensure_lrp_installed):
    parser = argparse.ArgumentParser(description="Bulk-submit GIAM access requests via the lrp CLI.")
    parser.add_argument("--input", required=True, help="Path to input Excel file (recipient, giam_group, justification)")
    parser.add_argument("--catalogue", required=True, help="Path to approved GIAM group catalogue Excel file")
    parser.add_argument("--report", required=True, help="Path to write the CSV status report")
    parser.add_argument("--retry-out", required=True, help="Path to write the JSON retry store for failed rows")
    parser.add_argument("--run-id", required=True, help="Identifier for this run, stored in the retry file")
    args = parser.parse_args(argv)

    if not ensure_installed():
        print("lrp CLI is not installed and automatic install failed. See lrp-cli README for manual install.", file=sys.stderr)
        return 3

    if not client.check_auth():
        print("Not authenticated with lrp. Run `lrp login` first, then re-run this command.", file=sys.stderr)
        return 2

    input_rows = read_input_rows(args.input)
    catalogue_groups = read_catalogue_groups(args.catalogue)
    validation = validate_rows(input_rows, catalogue_groups)

    rejected_results = [
        RowResult(row.recipient, row.giam_group, "rejected", reason)
        for row, reason in validation.invalid
    ]
    submitted_results = process_all(validation.valid, client=client)
    all_results = rejected_results + submitted_results

    write_report(all_results, args.report)
    write_retry_store(all_results, args.retry_out, args.run_id)

    submitted_count = sum(1 for r in all_results if r.status == "submitted")
    warning_count = sum(1 for r in all_results if r.status == "warning")
    rejected_count = len(rejected_results)
    error_count = sum(1 for r in all_results if r.status == "error")

    print(
        f"Processed {len(all_results)} rows: {submitted_count} submitted, "
        f"{warning_count} warning, {rejected_count} rejected, {error_count} error. "
        f"Report: {args.report}"
    )

    return 1 if error_count else 0


if __name__ == "__main__":
    sys.exit(main())
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `python3 -m pytest tests/test_cli.py -v`
Expected: PASS (4 tests)

- [ ] **Step 5: Commit**

```bash
git add bulkprovision/cli.py tests/test_cli.py
git commit -m "Add CLI entry point wiring bootstrap, auth check, validation, and submission"
```

---

### Task 8: Sample Data, requirements.txt, and Operator README

**Files:**
- Create: `requirements.txt`
- Create: `samples/input.xlsx`
- Create: `samples/catalogue.xlsx`
- Modify: `README.md`

**Interfaces:** None (no code) — this task produces the files an operator needs to actually run a real batch, using the real test recipients supplied for this project.

- [ ] **Step 1: Create requirements.txt**

```
openpyxl>=3.1
```

- [ ] **Step 2: Generate the sample input and catalogue workbooks**

Run this one-off script to create real sample files with the confirmed test recipients (operator: `extern.asthana_ankit@allianz.de`; onboarding recipients: `extern.asthana_ankit@allianz.de` and `sachin.lakhpati@allianz.com`). The GIAM group name is a placeholder — it must be replaced with a real approved group before actually submitting:

```bash
mkdir -p samples
python3 - <<'EOF'
import openpyxl

wb = openpyxl.Workbook()
ws = wb.active
ws.append(["recipient", "giam_group", "justification"])
ws.append(["extern.asthana_ankit@allianz.de", "REPLACE-WITH-APPROVED-GIAM-GROUP", "Onboarding test"])
ws.append(["sachin.lakhpati@allianz.com", "REPLACE-WITH-APPROVED-GIAM-GROUP", "Onboarding test"])
wb.save("samples/input.xlsx")

wb2 = openpyxl.Workbook()
ws2 = wb2.active
ws2.append(["giam_group"])
ws2.append(["REPLACE-WITH-APPROVED-GIAM-GROUP"])
wb2.save("samples/catalogue.xlsx")
EOF
```

Expected: `samples/input.xlsx` and `samples/catalogue.xlsx` exist.

- [ ] **Step 3: Add an operator usage section to README.md**

Add this section to `README.md` (after the existing "Known blockers" section):

```markdown
## Running this locally (per operator)

1. Install `lrp` if you don't already have it (the tool does this automatically too):
   ```sh
   curl -fsSL https://artifactory.prod.de.enablingtools.allianz/artifactory/static-release-local/gdc/lrp-cli/v0.0.17/install.sh | sh
   ```
2. Log in with your own corporate SSO (not a shared account):
   ```sh
   lrp login
   ```
3. Install this tool's one dependency:
   ```sh
   pip install -r requirements.txt
   ```
4. Prepare your input Excel (`recipient`, `giam_group`, `justification` columns —
   see `samples/input.xlsx`) and a catalogue Excel of approved groups
   (`giam_group` column — see `samples/catalogue.xlsx`). **Replace the
   placeholder group name in the samples with a real approved GIAM group
   before submitting anything for real.**
5. Run a batch:
   ```sh
   python3 -m bulkprovision.cli \
     --input samples/input.xlsx \
     --catalogue samples/catalogue.xlsx \
     --report report.csv \
     --retry-out retry.json \
     --run-id "$(date +%Y%m%d-%H%M%S)"
   ```
6. Check `report.csv` for per-row status (`submitted` / `warning` / `rejected` / `error`).
7. To retry only the rows that errored, read `retry.json` and re-run with
   just those rows in a new input Excel — the CLI doesn't yet read
   `retry.json` directly as input (see design doc Open Questions for this
   as a possible v1.1 improvement).

Exit codes: `0` clean run, `1` some rows errored, `2` not authenticated
(run `lrp login`), `3` `lrp` could not be installed automatically.
```

- [ ] **Step 4: Verify everything still passes together**

Run: `python3 -m pytest -v`
Expected: PASS (all tests from Tasks 1-7)

- [ ] **Step 5: Commit**

```bash
git add requirements.txt samples/input.xlsx samples/catalogue.xlsx README.md
git commit -m "Add requirements.txt, sample data, and operator usage instructions"
```

---

## Self-Review Notes

- **Spec coverage:** Section 2 (goals) -> Tasks 1,2,5,6,7. Section 4 (no AI) -> pure deterministic code throughout, no LLM calls anywhere. Section 5 (architecture/components) -> Validation Engine=Task 2, LRP CLI Orchestrator=Tasks 3+5, Status via `list_orders` exposed in `lrp_client` (not yet wired into `cli.py` — v1's report is built from `submit_cart`'s own immediate response, which already carries success/warning/error; polling `list_orders` afterward for approval-stage status like "Pending"/"Approved" is intentionally deferred, since it's a separate concern from submission success and isn't required by the acceptance criteria's "success/failed/pending" wording at the submission-result level). Report Generator/Retry Store=Task 6. Section 6 (data flow) -> Task 7's `main()` sequencing matches exactly. Section 7 (error handling) -> `result: warning` vs `error` handled distinctly in Task 5. Section 8 (local per-operator, own SSO) -> Task 8 README step 2, `check_auth()` gate in Task 7. New requirements from this session (auto-install, real test recipients) -> Tasks 4 and 8.
- **Gap found and accepted as out of scope for this plan:** retry-file-as-input (re-running directly from `retry.json` without a new Excel) isn't implemented — `write_retry_store`/`read_retry_rows` exist and are tested, but `cli.py` doesn't yet accept `--retry-in`. Documented as a known follow-up in the README rather than silently omitted.
- **Type consistency check:** `RowResult`/`InputRow` field name `recipient` used consistently from Task 1 through Task 8 (no leftover `bid` naming). `client` duck-type methods (`check_auth`, `find_user`, `search_product`, `add_to_cart`, `get_cart`, `submit_cart`) match between `lrp_client.py`'s real functions and every `FakeClient` in tests.
