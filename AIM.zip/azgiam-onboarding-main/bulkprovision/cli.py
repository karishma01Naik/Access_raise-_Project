"""Entry point: ensure lrp is installed, check auth, validate, submit, report."""
import argparse
import sys

from bulkprovision import lrp_client as default_client
from bulkprovision.ai_summary import generate_summary as default_generate_summary
from bulkprovision.bootstrap import ensure_lrp_installed
from bulkprovision.io_excel import read_input_rows
from bulkprovision.interactive import run_interactive_menu
from bulkprovision.orchestrator import process_all, RowResult
from bulkprovision.report import write_report, write_retry_store


def _format_row_line(result):
    return f"{result.recipient} | {result.giam_group} | {result.status} | {result.message}"


def run_batch(input_path, report_path, retry_path, run_id, client, generate_summary, skip_ai_summary=False):
    """Run one full batch: auth, submit, report. Returns an exit code.
    Shared by both the one-shot argparse path and the interactive menu's
    "run a batch" option, so the two never drift apart.

    There is no separate catalogue file/pre-check: `lrp search-products`
    (called per row inside process_all/process_recipient) is itself the
    validation - a group it can't find becomes an `error` row without
    blocking any of that recipient's other, valid groups."""
    if not client.check_auth():
        print("Not authenticated with lrp. Opening browser for login...", file=sys.stderr)
        if not client.login():
            print("Login failed or was not completed. Run `lrp login` manually, then re-run this command.", file=sys.stderr)
            return 2
        if not client.check_auth():
            print("Login completed but the session still isn't valid. Run `lrp login` manually, then re-run this command.", file=sys.stderr)
            return 2

    try:
        input_rows, unparseable_rows = read_input_rows(input_path)
    except Exception as exc:
        print(f"Failed to read/parse input Excel: {exc}", file=sys.stderr)
        return 4

    # Rows that couldn't even be parsed (blank recipient/group) are reported as
    # rejected rather than silently dropped, so the report covers every input row.
    rejected_results = [
        RowResult(
            f"row {row_number} ({reason})",
            f"row {row_number} ({reason})",
            "rejected",
            f"Input row {row_number} could not be processed: {reason}",
        )
        for row_number, reason in unparseable_rows
    ]
    # Live per-row progress, printed as each row finishes rather than only
    # at the very end - a bulk batch can take a while, and an operator
    # watching the terminal shouldn't have to wait in silence for every row.
    total_rows = len(rejected_results) + len(input_rows)
    progress_count = 0

    def _print_progress(result):
        nonlocal progress_count
        progress_count += 1
        print(f"[{progress_count}/{total_rows}] {_format_row_line(result)}")

    for rejected in rejected_results:
        _print_progress(rejected)

    # process_all/process_recipient are contractually non-raising (lrp failures
    # become RowResult(status="error")), so anything escaping here is a bug -
    # but a bug must not silently destroy a partially-submitted run's record.
    all_results = list(rejected_results)
    try:
        all_results.extend(process_all(input_rows, client=client, on_result=_print_progress))
        write_report(all_results, report_path)
        write_retry_store(all_results, retry_path, run_id)
    except Exception as exc:
        print(f"Unexpected error during processing/reporting: {exc}", file=sys.stderr)
        if all_results:
            try:
                write_report(all_results, report_path)
                write_retry_store(all_results, retry_path, run_id)
                print(
                    f"Partial results written to {report_path} - this report is INCOMPLETE; "
                    "verify against `lrp list-orders` before re-running.",
                    file=sys.stderr,
                )
            except Exception as write_exc:
                print(f"Could not write partial report: {write_exc}", file=sys.stderr)
        return 5

    submitted_count = sum(1 for r in all_results if r.status == "submitted")
    warning_count = sum(1 for r in all_results if r.status == "warning")
    rejected_count = len(rejected_results)
    error_count = sum(1 for r in all_results if r.status == "error")

    print(
        f"Processed {len(all_results)} rows: {submitted_count} submitted, "
        f"{warning_count} warning, {rejected_count} rejected, {error_count} error. "
        f"Report: {report_path}"
    )

    if not skip_ai_summary:
        # Best-effort only: never blocks or changes the exit code - a pure
        # presentation layer over the deterministic results computed above,
        # using the operator's own local Claude Code profile (no separate
        # API key needed). generate_summary() itself never raises by
        # design; the try/except here is defense-in-depth so this stays
        # true even if that contract is ever broken by a future change.
        try:
            summary = generate_summary(all_results)
        except Exception as exc:
            print(f"AI summary skipped (unexpected error): {exc}", file=sys.stderr)
            summary = None
        if summary:
            print("\n--- AI-generated summary (via local Claude Code) ---")
            print(summary)

    return 1 if error_count else 0


def main(
    argv=None,
    client=default_client,
    ensure_installed=ensure_lrp_installed,
    generate_summary=default_generate_summary,
    input_func=input,
    print_func=print,
):
    parser = argparse.ArgumentParser(description="Bulk-submit GIAM access requests via the lrp CLI.")
    parser.add_argument("--input", help="Path to input Excel file (recipient, giam_group, justification). Omit to launch the interactive menu instead.")
    parser.add_argument("--report", help="Path to write the CSV status report")
    parser.add_argument("--retry-out", help="Path to write the JSON retry store for failed rows")
    parser.add_argument("--run-id", help="Identifier for this run, stored in the retry file")
    parser.add_argument("--interactive", action="store_true", help="Launch the interactive menu even if batch arguments are also given")
    parser.add_argument(
        "--no-ai-summary", action="store_true",
        help="Skip the AI-generated plain-English summary (attempted by default via the local `claude` CLI; "
             "silently skipped if it's not installed - never affects the deterministic report or exit code)",
    )
    args = parser.parse_args(argv)

    if not ensure_installed():
        print("lrp CLI is not installed and automatic install failed. See lrp-cli README for manual install.", file=sys.stderr)
        return 3

    if args.interactive or not args.input:
        return run_interactive_menu(
            client=client,
            generate_summary=generate_summary,
            run_batch=run_batch,
            input_func=input_func,
            print_func=print_func,
        )

    missing = [
        flag for flag, value in (
            ("--report", args.report),
            ("--retry-out", args.retry_out), ("--run-id", args.run_id),
        ) if not value
    ]
    if missing:
        print(f"Batch mode requires {', '.join(missing)} when --input is given (or omit --input for the interactive menu).", file=sys.stderr)
        return 6

    return run_batch(
        args.input, args.report, args.retry_out, args.run_id,
        client, generate_summary, skip_ai_summary=args.no_ai_summary,
    )


if __name__ == "__main__":
    sys.exit(main())
