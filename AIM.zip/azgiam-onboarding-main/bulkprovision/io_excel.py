"""Read input rows from an Excel file."""
from dataclasses import dataclass

import openpyxl


@dataclass
class InputRow:
    recipient: str
    giam_group: str
    justification: str


def read_input_rows(path):
    """Read (recipient, giam_group, justification) rows from an input Excel file.

    Expects a header row with columns named exactly: recipient, giam_group,
    justification (case-insensitive, any column order).

    Returns a tuple ``(rows, skipped)``:
      - ``rows``: list[InputRow] for every fully-populated data row.
      - ``skipped``: list[tuple[int, str]] of (data row number, reason) for rows
        that couldn't be parsed because recipient or giam_group was blank. Row
        numbers are 1-based over the data rows (i.e. the first row after the
        header is 1). Entirely blank rows are ignored, not reported.

    Callers must surface ``skipped`` in the report so it covers 100% of the
    input rows rather than silently dropping unparseable ones.
    """
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    sheet = wb.active
    rows_iter = sheet.iter_rows(values_only=True)
    header = [str(h).strip().lower() if h is not None else "" for h in next(rows_iter)]
    try:
        recipient_idx = header.index("recipient")
        group_idx = header.index("giam_group")
        just_idx = header.index("justification")
    except ValueError as exc:
        raise ValueError(
            f"Input Excel must have columns: recipient, giam_group, justification. Found: {header}"
        ) from exc

    result = []
    skipped = []
    row_number = 0
    for row in rows_iter:
        # Counted for every data row (blank ones included) so a reported row
        # number maps to spreadsheet row row_number + 1.
        row_number += 1
        if row is None or all(cell is None for cell in row):
            continue
        recipient = str(row[recipient_idx]).strip() if row[recipient_idx] is not None else ""
        group = str(row[group_idx]).strip() if row[group_idx] is not None else ""
        justification = str(row[just_idx]).strip() if row[just_idx] is not None else ""
        if not recipient:
            skipped.append((row_number, "missing recipient"))
            continue
        if not group:
            skipped.append((row_number, "missing giam_group"))
            continue
        result.append(InputRow(recipient=recipient, giam_group=group, justification=justification))
    return result, skipped
