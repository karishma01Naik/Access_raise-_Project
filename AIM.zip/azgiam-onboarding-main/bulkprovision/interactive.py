"""Interactive menu wrapping every lrp operation this tool uses, so an
operator never has to type a raw `lrp` command themselves.
"""
import time

from bulkprovision.lrp_client import LrpError

MENU_TEXT = """
GIAM Bulk Provisioning - Interactive Menu
1) Run a bulk batch (input Excel)
2) Check authentication status
3) Log in (opens browser, falls back to --manual if needed)
4) Find a user
5) Search for a GIAM group/product
6) List your recent orders
7) Exit
"""


def _run_batch_flow(client, generate_summary, run_batch, input_func, print_func):
    input_path = input_func("Input Excel path: ").strip()
    if not input_path:
        print_func("An input path is required.")
        return
    run_id = time.strftime("%Y%m%d-%H%M%S")
    report_path = f"report-{run_id}.csv"
    retry_path = f"retry-{run_id}.json"
    exit_code = run_batch(input_path, report_path, retry_path, run_id, client, generate_summary)
    print_func(f"(batch finished, exit code {exit_code})")


def _check_auth_flow(client, print_func):
    if client.check_auth():
        print_func("Authenticated - cookie is valid.")
    else:
        print_func("Not authenticated. Choose option 3 to log in.")


def _login_flow(client, print_func):
    # force=True: an operator explicitly choosing "Log in" wants a
    # guaranteed-fresh session, not a silent "already authenticated"
    # short-circuit on whatever cookie happens to be cached already.
    print_func("Opening browser for a fresh login (falls back to --manual if that fails)...")
    if client.login(force=True):
        print_func("Login succeeded.")
    else:
        print_func("Login failed or was not completed.")


def _format_user(user):
    name = user.get("name") or "?"
    email = user.get("email") or "?"
    user_id = user.get("id") or "?"
    return f"{name} <{email}>  (id={user_id})"


def _format_product(product):
    name = product.get("name") or "?"
    description = product.get("description") or ""
    product_id = product.get("productId") or "?"
    detail = f"\n  {description}" if description else ""
    return f"{name}  (productId={product_id}){detail}"


def _format_status(status):
    """lrp's real status field is an object (e.g. {'Value': 'Assigned',
    'DisplayValue': 'Canceled', 'IsReadOnly': True}), not a plain string -
    prefer the human label, fall back to the raw value."""
    if isinstance(status, dict):
        return status.get("DisplayValue") or status.get("Value") or "?"
    return status or "?"


def _format_order(order):
    title = order.get("title") or "?"
    status = _format_status(order.get("status"))
    created = order.get("createdDate") or "?"
    return f"{title:<45} {status:<12} created {created}"


def _find_user_flow(client, input_func, print_func):
    recipient = input_func("Recipient (email/name/ID): ").strip()
    if not recipient:
        print_func("A recipient is required.")
        return
    try:
        user = client.find_user(recipient)
        print_func(f"Found: {_format_user(user)}")
    except LrpError as exc:
        print_func(f"Error: {exc.message}")


def _search_product_flow(client, input_func, print_func):
    query = input_func("GIAM group/product name (exact match): ").strip()
    if not query:
        print_func("A group name is required.")
        return
    try:
        product = client.search_product(query)
        print_func(f"Found: {_format_product(product)}")
    except LrpError as exc:
        print_func(f"Error: {exc.message}")


def _list_orders_flow(client, print_func):
    try:
        orders = client.list_orders()
    except LrpError as exc:
        print_func(f"Error: {exc.message}")
        return
    if not orders:
        print_func("No orders found.")
        return
    for order in orders:
        print_func(_format_order(order))


_EXIT_CHOICES = {"7", "q", "quit", "exit"}


def run_interactive_menu(client, generate_summary, run_batch, input_func=input, print_func=print):
    """Loop showing the menu and dispatching to the chosen operation until
    the operator exits (option 7, or EOF/Ctrl-C). Returns an exit code."""
    while True:
        print_func(MENU_TEXT)
        try:
            choice = input_func("Choice: ").strip()
        except (EOFError, KeyboardInterrupt):
            print_func("\nExiting.")
            return 0

        if choice.lower() in _EXIT_CHOICES:
            print_func("Goodbye.")
            return 0

        try:
            if choice == "1":
                _run_batch_flow(client, generate_summary, run_batch, input_func, print_func)
            elif choice == "2":
                _check_auth_flow(client, print_func)
            elif choice == "3":
                _login_flow(client, print_func)
            elif choice == "4":
                _find_user_flow(client, input_func, print_func)
            elif choice == "5":
                _search_product_flow(client, input_func, print_func)
            elif choice == "6":
                _list_orders_flow(client, print_func)
            else:
                print_func(f"Unknown choice: {choice!r}")
        except (EOFError, KeyboardInterrupt):
            print_func("\nExiting.")
            return 0
