"""Optional, best-effort natural-language summary of a run's results.

Invokes the operator's own local `claude` CLI (Claude Code) in
non-interactive print mode, so it runs under the operator's existing
profile/subscription - no separate API key or AWS Bedrock wiring needed.

This is a pure presentation layer over already-computed, deterministic
RowResults - it never re-classifies or re-judges an outcome, only phrases
it in plain English. If `claude` isn't installed, times out, or fails for
any reason, this returns None and the caller proceeds with the deterministic
report exactly as if this module didn't exist - but every one of those
"return None" paths now also prints one line to stderr saying which failure
mode it was (added 2026-08-21: a real run had `claude` installed and on
PATH, yet the summary never appeared, with zero diagnostic output - every
failure branch below was completely silent by design, which made this
undiagnosable without re-running and guessing).
"""
import shutil
import subprocess
import sys

AI_SUMMARY_TIMEOUT_SECONDS = 60

_PROMPT_HEADER = """\
You are summarizing the results of a GIAM (identity access management) bulk
access request run for a Cloud Ops audience. Produce ONLY the following,
nothing else - no preamble, no "what these statuses mean" glossary, no
restating these instructions:

1. One bold headline line with the total and per-status counts, e.g.
   "**3 requests: 1 submitted, 1 warning, 0 rejected, 1 error.**"
2. A single markdown table with one row per input row (every row given
   below, submitted rows included - never omit any), columns exactly:
   Recipient | Group | Status | Reason. Keep each Reason cell to one short
   plain-English clause - no inventing details beyond what's given below.
   For a warning row's Reason, state plainly that the recipient already has
   (or already requested) that access, and that this is NOT a failure.
3. If there is at least one error row, one closing line: failed rows are in
   the retry file and can be re-run. Do not add this line if there are zero
   error rows, and never say this about warning rows - warning rows are
   never in the retry file and never need re-running.
Be factual and concise - do not speculate beyond the data given.

"""


def _build_prompt(results):
    counts = {"submitted": 0, "warning": 0, "rejected": 0, "error": 0}
    for r in results:
        counts[r.status] = counts.get(r.status, 0) + 1

    lines = [
        _PROMPT_HEADER,
        f"Totals: {len(results)} rows processed - {counts['submitted']} submitted, "
        f"{counts['warning']} warning, {counts['rejected']} rejected, {counts['error']} error.",
        "",
        "Rows:",
    ]
    for r in results:
        lines.append(f"status={r.status} recipient={r.recipient} group={r.giam_group} reason={r.message}")
    return "\n".join(lines)


def _skip(reason):
    print(f"AI summary skipped: {reason}", file=sys.stderr)
    return None


def generate_summary(results, run=subprocess.run, which=shutil.which):
    """Return an AI-generated natural-language summary string, or None if
    the local `claude` CLI isn't available or the call fails for any
    reason. Never raises. Every skip path prints its specific reason to
    stderr - this is best-effort, not silent-and-undiagnosable."""
    if not results:
        return _skip("no results to summarize")
    if which("claude") is None:
        return _skip("the `claude` CLI was not found on PATH")

    prompt = _build_prompt(results)
    try:
        completed = run(
            ["claude", "-p", prompt],
            capture_output=True, text=True, timeout=AI_SUMMARY_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        return _skip(f"`claude -p` did not finish within {AI_SUMMARY_TIMEOUT_SECONDS}s")
    if completed.returncode != 0:
        stderr_tail = (completed.stderr or "").strip()[-300:]
        return _skip(f"`claude -p` exited with code {completed.returncode}: {stderr_tail or '(no stderr output)'}")
    summary = completed.stdout.strip()
    if not summary:
        return _skip("`claude -p` returned exit code 0 but produced no output")
    return summary
