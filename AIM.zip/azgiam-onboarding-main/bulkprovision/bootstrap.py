"""Ensure the `lrp` CLI is installed before running a batch."""
import shutil
import subprocess

# Official install script from lrp-cli/README.md - internal Artifactory host.
INSTALL_SCRIPT_URL = "https://artifactory.prod.de.enablingtools.allianz/artifactory/static-release-local/gdc/lrp-cli/v0.0.17/install.sh"

# Bound the install so a hung Artifactory/proxy can't block a batch forever.
INSTALL_TIMEOUT_SECONDS = 60


def ensure_lrp_installed(run=subprocess.run, which=shutil.which):
    """Return True if `lrp` is on PATH after this call, installing it via
    the official install script first if it wasn't already present."""
    if which("lrp") is not None:
        return True

    try:
        result = run(
            f"curl -fsSL {INSTALL_SCRIPT_URL} | sh",
            shell=True, capture_output=True, text=True, timeout=INSTALL_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        return False
    if result.returncode != 0:
        return False
    return which("lrp") is not None
