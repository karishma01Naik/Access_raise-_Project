"""Coordinate validated input rows through the lrp CLI, per recipient."""
from dataclasses import dataclass

from bulkprovision.lrp_client import LrpError

# Verbatim copy of lrp-cli's cmd/order_messages.go (orderResultMessages) so
# reports read the same sentences a human running `lrp` directly would see.
RESULT_MESSAGES = {
    "SUCCESS": "Order submitted successfully.",
    # Self-order duplicates
    "ERROR_SELF_DUPLICATE": "You already have (or have already requested) this product, so it was not ordered.",
    "ERROR_SELF_ALL_DUPLICATES": "You already have (or have already requested) all of these products, so nothing was ordered.",
    "WARNING_SELF_SOME_DUPLICATES": "Some products were already assigned or requested for you and were skipped; the rest were ordered.",
    # Single on-behalf-of duplicates
    "ERROR_ONE_ON_BEHALF_DUPLICATE": "The recipient already has (or has already requested) this product, so it was not ordered.",
    "ERROR_ONE_ON_BEHALF_ALL_DUPLICATES": "The recipient already has (or has already requested) all of these products, so nothing was ordered.",
    "WARNING_ONE_ON_BEHALF_SOME_DUPLICATES": "Some products were already assigned or requested for the recipient and were skipped; the rest were ordered.",
    # Multiple on-behalf-of duplicates
    "WARNING_SOME_ON_BEHALF_DUPLICATE": "Some recipients already had this product and were skipped; the rest were ordered.",
    "WARNING_SOME_ON_BEHALF_SOME_DUPLICATES": "Some products were already assigned or requested for some recipients and were skipped; the rest were ordered.",
    "ERROR_ALL_ON_BEHALF_DUPLICATE": "All recipients already have (or have already requested) this product, so nothing was ordered.",
    "ERROR_ALL_ON_BEHALF_ALL_DUPLICATES": "All recipients already have (or have already requested) all of these products, so nothing was ordered.",
    "ERROR_DUPLICATES_UNKNOWN": "The order could not be completed due to an unresolved duplicate check.",
    # General order outcomes
    "ERROR_UNKNOWN": "The order failed for an unknown reason.",
    "ERROR_GENERAL": "The order completed with errors.",
    "ERROR_ORDER_FAILED": "The order could not be submitted.",
}

NO_MESSAGE_FALLBACK = "lrp returned no error message for this outcome"


def humanize(message_key):
    return RESULT_MESSAGES.get(message_key, message_key)


def _already_submitted_message(detail):
    """A clear, direct reason for warning rows - this access was already
    requested/assigned for this user in a prior request, so nothing new
    was submitted this time. `detail` carries lrp's own message for
    traceability, but the leading sentence is unambiguous on its own."""
    return f"This request was already submitted/assigned previously for this user. (lrp: {detail})"


@dataclass
class RowResult:
    recipient: str
    giam_group: str
    status: str
    message: str


def _normalize(value):
    """Normalize an identifier for comparison (strip + lowercase)."""
    if value is None:
        return ""
    return str(value).strip().lower()


def _flatten_skipped_identifiers(non_requestable):
    """Collect normalized product names *and* productIds flagged as
    non-requestable (i.e. duplicates) by submit-cart.

    Both fields are collected because a nonRequestableProducts entry can carry
    only a usable productId with an empty/missing name, and normalization keeps
    matching consistent with validation.validate_rows / search_product.
    """
    identifiers = set()
    for products in non_requestable.values():
        for product in products or []:
            for key in ("name", "productId"):
                normalized = _normalize(product.get(key))
                if normalized:
                    identifiers.add(normalized)
    return identifiers


def process_recipient(recipient, rows, client, on_result=None):
    """Process all valid rows for a single recipient, one `lrp order-product`
    call per row - no cart involved at all (`order-product` is lrp-cli's own
    "Submit a single product order directly without using the cart").
    Switched from the add-to-cart/get-cart/submit-cart cart flow on
    2026-08-20: every real bulk run hit an empty cart immediately after a
    successful add-to-cart, for every recipient tried (including ones known
    to already have the access, ruling out a permissions cause), across two
    different attempted fixes - order-product sidesteps that failure class
    entirely by never touching a cart. Each row is now fully independent:
    one row failing never blocks or contaminates any other row, for this
    recipient or any other. Never raises - lrp_client errors become
    status='error'.

    on_result, if given, is called with each RowResult as soon as it's
    produced - e.g. so a caller can print live per-row progress instead of
    waiting for the whole batch to finish."""
    results = []

    def _emit(result):
        results.append(result)
        if on_result is not None:
            on_result(result)

    try:
        user = client.find_user(recipient)
    except LrpError as exc:
        for row in rows:
            _emit(RowResult(recipient, row.giam_group, "error", exc.message))
        return results

    for row in rows:
        try:
            product = client.search_product(row.giam_group)
        except LrpError as exc:
            _emit(RowResult(recipient, row.giam_group, "error", exc.message))
            continue

        try:
            reason = row.justification or "Bulk onboarding access request"
            response = client.order_product(product, reason, user)
        except LrpError as exc:
            _emit(RowResult(recipient, row.giam_group, "error", exc.message))
            continue

        result_kind = response.get("result", "error")
        raw_message = response.get("message", "")
        message = humanize(raw_message) or NO_MESSAGE_FALLBACK
        non_requestable = response.get("nonRequestableProducts") or {}
        skipped_identifiers = _flatten_skipped_identifiers(non_requestable)
        # Belt-and-braces: any duplicate-flavoured result key is a warning,
        # not an error, even if the product wasn't echoed back in
        # nonRequestableProducts.
        message_flags_duplicate = "duplicate" in _normalize(raw_message)
        row_identifiers = {
            _normalize(product.get("name") or row.giam_group),
            _normalize(product.get("productId")),
        } - {""}

        if row_identifiers & skipped_identifiers:
            _emit(RowResult(recipient, row.giam_group, "warning", _already_submitted_message(message)))
        elif result_kind == "error":
            if message_flags_duplicate:
                _emit(RowResult(recipient, row.giam_group, "warning", _already_submitted_message(message)))
            else:
                _emit(RowResult(recipient, row.giam_group, "error", message))
        else:
            _emit(RowResult(recipient, row.giam_group, "submitted", message))

    return results


def process_all(valid_rows, client, on_result=None):
    """Process all valid rows, grouped by recipient, one recipient fully
    completed before the next starts. Returns a flat list of RowResult.

    on_result, if given, is called with each RowResult as soon as it's
    produced, across every recipient - see process_recipient."""
    rows_by_recipient = {}
    for row in valid_rows:
        rows_by_recipient.setdefault(row.recipient, []).append(row)

    all_results = []
    for recipient, rows in rows_by_recipient.items():
        all_results.extend(process_recipient(recipient, rows, client, on_result=on_result))
    return all_results
