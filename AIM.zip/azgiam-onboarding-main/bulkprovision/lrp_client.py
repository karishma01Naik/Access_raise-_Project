"""Thin wrapper around the `lrp` CLI: JSON in, JSON out, errors as exceptions."""
import json
import subprocess


# Every lrp invocation is a short HTTP round-trip; without a timeout a hung
# proxy or expired session prompt would block a whole batch indefinitely.
LRP_TIMEOUT_SECONDS = 60

# `lrp login` itself waits up to 5 minutes for the operator to complete SSO
# in the browser it opens (or the manual cookie-paste fallback) - give it
# more than that so we time out the wrapper only if login itself is stuck.
LOGIN_TIMEOUT_SECONDS = 330


class LrpError(Exception):
    def __init__(self, code, message):
        self.code = code
        self.message = message
        super().__init__(f"{code}: {message}")


def _normalize(value):
    """Normalize a string for comparison (strip + lowercase)."""
    if value is None:
        return ""
    return str(value).strip().lower()


def check_auth():
    """Return True if the current lrp session is authenticated."""
    try:
        completed = subprocess.run(
            ["lrp", "check-auth"], capture_output=True, text=True, timeout=LRP_TIMEOUT_SECONDS
        )
    except subprocess.TimeoutExpired:
        return False
    return completed.returncode == 0


def login(force=False):
    """Run `lrp login` interactively, inheriting the caller's terminal so the
    operator sees the browser-launch progress and completes SSO themselves.

    If the automated browser fails outright (observed in practice: its
    isolated Chromium doesn't share the operator's regular browser's
    certificate trust store, so it can fail even when the operator's own
    browser works fine), fall back to `--manual` cookie-paste, which never
    launches an automated browser and so isn't affected by that failure
    mode. A timeout (rather than a fast failure) skips the fallback, since
    a hang suggests a different problem than a cert-trust mismatch, and
    chaining another 5+ minute wait onto an already-stuck attempt isn't
    useful.

    By default, `lrp login` short-circuits to "Already authenticated" if a
    still-valid session is already cached - it never re-prompts. Pass
    force=True to always genuinely re-authenticate (pass-through to lrp's
    own `--force` flag), e.g. when the operator wants a guaranteed-fresh
    session regardless of whatever is currently cached.

    This only invokes lrp's own existing interactive login flows - it never
    handles credentials itself. Returns True if login succeeded."""
    browser_args = ["lrp", "login"] + (["--force"] if force else [])
    try:
        completed = subprocess.run(browser_args, timeout=LOGIN_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        return False
    if completed.returncode == 0:
        return True

    manual_args = ["lrp", "login", "--manual"] + (["--force"] if force else [])
    try:
        completed = subprocess.run(manual_args, timeout=LOGIN_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        return False
    return completed.returncode == 0


def _run(args):
    """Run `lrp <args> -o json` and return the parsed JSON response.

    Raises LrpError if the CLI signals a top-level error via
    {"error": true, "code", "message"} - this covers auth/HTTP/connection
    failures uniformly across every command. Note: distinguishes the generic
    error envelope (always has "code") from response-level "error" flags
    in get-cart/list-orders (no "code"), which pass through as normal data.

    Every failure mode - timeout, non-JSON stdout, error envelope - is raised
    as LrpError, so callers only ever have to handle that one exception type.
    """
    try:
        completed = subprocess.run(
            ["lrp", *args, "-o", "json"], capture_output=True, text=True,
            timeout=LRP_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired as exc:
        raise LrpError("TIMEOUT", "lrp command timed out") from exc

    stdout = completed.stdout.strip()
    if not stdout:
        raise LrpError("NO_OUTPUT", completed.stderr.strip() or "lrp produced no output")

    try:
        data = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise LrpError("INVALID_JSON", f"lrp returned non-JSON output: {exc}") from exc
    if isinstance(data, dict) and data.get("error") is True and "code" in data:
        raise LrpError(data["code"], data.get("message", "lrp reported an error"))
    return data


def find_user(recipient):
    """Return the single matching user object for a recipient (email, name,
    or ID), or raise LrpError if zero or multiple matches are found.

    `find-user` can return an account whose own `email` field doesn't
    actually match the recipient string that was searched for (e.g. it
    returns only an M365 admin/service account for that person, with a
    completely different @allianzms.onmicrosoft.com address) - this is not
    just an ambiguity-when-multiple-results problem, so whenever `recipient`
    looks like an email address, an exact (case-insensitive) email match is
    *always* required, never "whichever one came back," regardless of how
    many results `find-user` returned. Never fall back to a result whose
    email doesn't match - that risks silently acting on behalf of the wrong
    (e.g. admin/service) account.

    Confirmed in practice: some account types (M365 admin/service accounts)
    have a completely blank `email` field - the address only appears
    embedded as a suffix of the display `name` (e.g. "Lakhpati, Sachin
    (Allianz Technology SE) - M365 Admin Account -
    adm_wgbh5c9@allianzms.onmicrosoft.com"). For those specifically (`email`
    blank/missing), fall back to matching the `name` suffix - but never for
    an account whose `email` is populated with something else, since that
    would defeat the entire point of requiring an exact match.
    """
    data = _run(["find-user", recipient])
    items = data.get("items", [])
    if "@" in recipient:
        recipient_email = recipient.strip().lower()
        exact_matches = [
            item for item in items
            if (item.get("email") or "").strip().lower() == recipient_email
        ]
        if len(exact_matches) == 1:
            return exact_matches[0]
        if len(exact_matches) > 1:
            raise LrpError(
                "AMBIGUOUS_USER",
                f"Multiple accounts with email exactly matching '{recipient}' found ({len(exact_matches)})",
            )

        name_suffix_matches = [
            item for item in items
            if not (item.get("email") or "").strip()
            and _normalize(item.get("name")).endswith(recipient_email)
        ]
        if len(name_suffix_matches) == 1:
            return name_suffix_matches[0]
        if len(name_suffix_matches) > 1:
            raise LrpError(
                "AMBIGUOUS_USER",
                f"Multiple accounts with a name ending in '{recipient}' found ({len(name_suffix_matches)})",
            )

        seen = [
            f"email={item.get('email')!r} name={item.get('name')!r}"
            for item in items
        ]
        raise LrpError(
            "USER_NOT_FOUND",
            f"No account with email exactly matching '{recipient}' "
            f"(lrp find-user returned {len(items)} result(s), none with that exact "
            f"email - actual field values: {seen})",
        )
    if len(items) != 1:
        raise LrpError(
            "AMBIGUOUS_USER" if len(items) > 1 else "USER_NOT_FOUND",
            f"Expected exactly one match for '{recipient}', found {len(items)}",
        )
    return items[0]


def search_product(group_name):
    """Return the single product object matching a GIAM group name exactly
    (case-insensitive), or raise LrpError if not found or ambiguous."""
    data = _run(["search-products", group_name])
    products = data.get("products", [])
    matches = [p for p in products if p.get("name", "").strip().lower() == group_name.strip().lower()]
    if len(matches) != 1:
        raise LrpError(
            "PRODUCT_NOT_FOUND",
            f"Expected exactly one exact match for '{group_name}', found {len(matches)}",
        )
    return matches[0]


def add_to_cart(products):
    """Add product objects (as returned by search_product) to the cart."""
    payload = [{**p, "isAddedToCart": False} for p in products]
    return _run(["add-to-cart", "--products", json.dumps(payload)])


def get_cart():
    """Return the current cart contents."""
    return _run(["get-cart"])


def submit_cart(items, reason, on_behalf_of):
    """Submit cart items on behalf of a user. Returns the parsed response,
    which always has 'result' ('success'|'warning'|'error') and 'message'.
    Does not raise on 'warning'/'error' result - callers inspect it."""
    return _run([
        "submit-cart",
        "--items", json.dumps(items),
        "--reason", reason,
        "--on-behalf-of", json.dumps(on_behalf_of),
    ])


def order_product(product, reason, on_behalf_of=None):
    """Submit a single product order directly, with no cart involved at all
    (posts straight to /api/products/order, a different endpoint than
    submit-cart's /api/cart/submit) - added 2026-08-20 after real bulk runs
    kept hitting an empty cart immediately after a successful add-to-cart,
    for every recipient tried, including ones known to already have the
    access. Returns the parsed response, which always has 'result'
    ('success'|'warning'|'error') and 'message', same shape as submit_cart's
    response. Does not raise on 'warning'/'error' result - callers inspect
    it. on_behalf_of=None orders for the operator themselves."""
    args = [
        "order-product",
        "--product", json.dumps({**product, "isAddedToCart": False}),
        "--reason", reason,
    ]
    if on_behalf_of is not None:
        args += ["--on-behalf-of", json.dumps(on_behalf_of)]
    return _run(args)


def list_orders():
    """Return the list of orders for the current session's account."""
    data = _run(["list-orders"])
    return data.get("productRequests", [])
