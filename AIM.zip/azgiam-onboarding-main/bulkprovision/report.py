"""Write per-run status reports and a retry store for failed rows."""
import csv
import json
from pathlib import Path


def _ensure_parent(path):
    """Create the output file's parent directory if needed, so a run that has
    already submitted requests never loses its report to a missing dir."""
    parent = Path(path).parent
    if str(parent):
        parent.mkdir(parents=True, exist_ok=True)


def write_report(results, path):
    """Write one row per RowResult to a CSV report."""
    _ensure_parent(path)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["recipient", "giam_group", "status", "message"])
        for r in results:
            writer.writerow([r.recipient, r.giam_group, r.status, r.message])


def write_retry_store(results, path, run_id):
    """Write rows with status 'error' to a JSON retry file, keyed by run_id."""
    _ensure_parent(path)
    retryable = [
        {"recipient": r.recipient, "giam_group": r.giam_group, "reason": r.message}
        for r in results if r.status == "error"
    ]
    Path(path).write_text(
        json.dumps({"run_id": run_id, "rows": retryable}, indent=2), encoding="utf-8"
    )


def read_retry_rows(path):
    """Read rows from a retry store file. Returns [] if the file doesn't exist."""
    p = Path(path)
    if not p.exists():
        return []
    return json.loads(p.read_text(encoding="utf-8")).get("rows", [])
