from unittest.mock import MagicMock

import pytest

from bulkprovision.ai_summary import _PROMPT_HEADER, _build_prompt, generate_summary
from bulkprovision.orchestrator import RowResult


def _results():
    return [
        RowResult("a@b.com", "APP-GITHUB-ADMIN", "submitted", "Order submitted successfully."),
        RowResult("c@d.com", "APP-GITHUB-READ", "warning", "This request was already submitted/assigned previously for this user. (lrp: Some products were already assigned or requested for the recipient; the rest were ordered.)"),
        RowResult("e@f.com", "APP-UNKNOWN", "rejected", "row 5: missing recipient"),
        RowResult("g@h.com", "APP-GITHUB-ADMIN", "error", "Expected exactly one match for 'g@h.com', found 0"),
    ]


def test_generate_summary_returns_none_when_claude_not_installed(capsys):
    which = MagicMock(return_value=None)
    run = MagicMock()
    assert generate_summary(_results(), run=run, which=which) is None
    run.assert_not_called()
    assert "not found on PATH" in capsys.readouterr().err


def test_generate_summary_returns_none_for_empty_results(capsys):
    which = MagicMock(return_value="/usr/bin/claude")
    run = MagicMock()
    assert generate_summary([], run=run, which=which) is None
    run.assert_not_called()
    assert "no results" in capsys.readouterr().err


def test_generate_summary_returns_stdout_on_success():
    which = MagicMock(return_value="/usr/bin/claude")
    run = MagicMock(return_value=MagicMock(returncode=0, stdout="## Summary\n\nAll good.\n"))
    summary = generate_summary(_results(), run=run, which=which)
    assert summary == "## Summary\n\nAll good."


def test_generate_summary_invokes_claude_print_mode_with_prompt_containing_row_detail():
    which = MagicMock(return_value="/usr/bin/claude")
    run = MagicMock(return_value=MagicMock(returncode=0, stdout="summary"))
    generate_summary(_results(), run=run, which=which)

    args, kwargs = run.call_args
    command = args[0]
    assert command[0] == "claude"
    assert command[1] == "-p"
    prompt = command[2]
    assert "a@b.com" in prompt  # submitted rows must be included too, not just failures
    assert "c@d.com" in prompt
    assert "APP-UNKNOWN" in prompt
    assert "g@h.com" in prompt
    assert "4 rows processed" in prompt
    assert kwargs["timeout"] > 0


def test_build_prompt_includes_every_row_not_just_failures():
    built = _build_prompt(_results())
    assert "status=submitted recipient=a@b.com" in built
    assert "status=warning recipient=c@d.com" in built
    assert "status=rejected recipient=e@f.com" in built
    assert "status=error recipient=g@h.com" in built


def test_prompt_asks_for_table_headline_and_no_glossary():
    assert "Recipient | Group | Status | Reason" in _PROMPT_HEADER
    assert "bold headline" in _PROMPT_HEADER
    assert "no \"what these statuses mean\" glossary" in _PROMPT_HEADER


def test_prompt_instructs_warning_rows_as_already_submitted_not_a_failure():
    """The 'already submitted/assigned' detail from
    orchestrator._already_submitted_message must reach the model verbatim,
    and the instructions must make clear a warning row is not a failure
    needing retry."""
    built = _build_prompt(_results())
    assert "already submitted/assigned previously for this user" in built
    assert "NOT a failure" in _PROMPT_HEADER
    assert "never in the retry file" in _PROMPT_HEADER


def test_generate_summary_returns_none_on_nonzero_exit_and_reports_stderr(capsys):
    which = MagicMock(return_value="/usr/bin/claude")
    run = MagicMock(return_value=MagicMock(returncode=1, stdout="", stderr="permission denied"))
    assert generate_summary(_results(), run=run, which=which) is None
    err = capsys.readouterr().err
    assert "exited with code 1" in err
    assert "permission denied" in err


def test_generate_summary_returns_none_on_timeout_and_reports_it(capsys):
    import subprocess

    which = MagicMock(return_value="/usr/bin/claude")
    run = MagicMock(side_effect=subprocess.TimeoutExpired(cmd="claude", timeout=60))
    assert generate_summary(_results(), run=run, which=which) is None
    assert "did not finish within" in capsys.readouterr().err


def test_generate_summary_returns_none_on_blank_stdout_and_reports_it(capsys):
    which = MagicMock(return_value="/usr/bin/claude")
    run = MagicMock(return_value=MagicMock(returncode=0, stdout="   \n  "))
    assert generate_summary(_results(), run=run, which=which) is None
    assert "produced no output" in capsys.readouterr().err
