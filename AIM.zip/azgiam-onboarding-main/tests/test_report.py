import csv
import json

from bulkprovision.orchestrator import RowResult
from bulkprovision.report import write_report, write_retry_store, read_retry_rows


def test_write_report_writes_one_row_per_result(tmp_path):
    results = [
        RowResult("extern.asthana_ankit@allianz.de", "APP-GITHUB-ADMIN", "submitted", "Order submitted successfully."),
        RowResult("sachin.lakhpati@allianz.com", "APP-UNKNOWN", "rejected", "not in catalogue"),
    ]
    path = tmp_path / "report.csv"

    write_report(results, path)

    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    assert rows == [
        {"recipient": "extern.asthana_ankit@allianz.de", "giam_group": "APP-GITHUB-ADMIN", "status": "submitted", "message": "Order submitted successfully."},
        {"recipient": "sachin.lakhpati@allianz.com", "giam_group": "APP-UNKNOWN", "status": "rejected", "message": "not in catalogue"},
    ]


def test_write_retry_store_only_includes_error_rows(tmp_path):
    results = [
        RowResult("a@b.com", "APP-GITHUB-ADMIN", "submitted", "ok"),
        RowResult("b@b.com", "APP-UNKNOWN", "error", "boom"),
    ]
    path = tmp_path / "retry.json"

    write_retry_store(results, path, run_id="run-1")

    payload = json.loads(path.read_text())
    assert payload["run_id"] == "run-1"
    assert payload["rows"] == [{"recipient": "b@b.com", "giam_group": "APP-UNKNOWN", "reason": "boom"}]


def test_write_report_creates_missing_parent_directories(tmp_path):
    results = [RowResult("a@b.com", "APP-GITHUB-ADMIN", "submitted", "ok")]
    path = tmp_path / "nested" / "dir" / "report.csv"

    write_report(results, path)

    assert path.exists()
    with open(path, newline="", encoding="utf-8") as f:
        assert list(csv.DictReader(f))[0]["recipient"] == "a@b.com"


def test_write_retry_store_creates_missing_parent_directories(tmp_path):
    results = [RowResult("a@b.com", "APP-GITHUB-ADMIN", "error", "boom")]
    path = tmp_path / "nested" / "dir" / "retry.json"

    write_retry_store(results, path, run_id="run-1")

    assert json.loads(path.read_text(encoding="utf-8"))["rows"][0]["reason"] == "boom"


def test_report_round_trips_non_ascii_names(tmp_path):
    results = [RowResult("Müller, Jörg", "APP-GITHUB-ADMIN", "error", "Übertragung fehlgeschlagen")]
    report_path = tmp_path / "report.csv"
    retry_path = tmp_path / "retry.json"

    write_report(results, report_path)
    write_retry_store(results, retry_path, run_id="run-1")

    with open(report_path, newline="", encoding="utf-8") as f:
        assert list(csv.DictReader(f))[0]["recipient"] == "Müller, Jörg"
    assert read_retry_rows(retry_path)[0]["recipient"] == "Müller, Jörg"


def test_read_retry_rows_returns_empty_list_when_missing(tmp_path):
    assert read_retry_rows(tmp_path / "missing.json") == []


def test_read_retry_rows_round_trips(tmp_path):
    results = [RowResult("a@b.com", "APP-GITHUB-ADMIN", "error", "boom")]
    path = tmp_path / "retry.json"
    write_retry_store(results, path, run_id="run-1")

    rows = read_retry_rows(path)

    assert rows == [{"recipient": "a@b.com", "giam_group": "APP-GITHUB-ADMIN", "reason": "boom"}]
