import json
import subprocess
from unittest.mock import patch, MagicMock

import pytest

from bulkprovision.lrp_client import (
    check_auth, login, find_user, search_product, add_to_cart, get_cart,
    submit_cart, order_product, list_orders, LrpError, LRP_TIMEOUT_SECONDS, LOGIN_TIMEOUT_SECONDS,
)


def _mock_completed(stdout_obj, stderr="", returncode=0):
    completed = MagicMock()
    completed.stdout = json.dumps(stdout_obj)
    completed.stderr = stderr
    completed.returncode = returncode
    return completed


@patch("bulkprovision.lrp_client.subprocess.run")
def test_check_auth_true_on_exit_zero(mock_run):
    mock_run.return_value = MagicMock(returncode=0)
    assert check_auth() is True
    mock_run.assert_called_once_with(
        ["lrp", "check-auth"], capture_output=True, text=True, timeout=LRP_TIMEOUT_SECONDS
    )


@patch("bulkprovision.lrp_client.subprocess.run")
def test_check_auth_false_on_nonzero_exit(mock_run):
    mock_run.return_value = MagicMock(returncode=1)
    assert check_auth() is False


@patch("bulkprovision.lrp_client.subprocess.run")
def test_login_true_on_exit_zero(mock_run):
    mock_run.return_value = MagicMock(returncode=0)
    assert login() is True
    mock_run.assert_called_once_with(["lrp", "login"], timeout=LOGIN_TIMEOUT_SECONDS)


@patch("bulkprovision.lrp_client.subprocess.run")
def test_login_false_on_nonzero_exit(mock_run):
    mock_run.return_value = MagicMock(returncode=1)
    assert login() is False


@patch("bulkprovision.lrp_client.subprocess.run")
def test_login_does_not_capture_output(mock_run):
    """login() must inherit the caller's terminal (no capture_output) so the
    operator sees lrp's own browser-launch progress and can complete SSO or
    the manual cookie-paste fallback interactively."""
    mock_run.return_value = MagicMock(returncode=0)
    login()
    _, kwargs = mock_run.call_args
    assert "capture_output" not in kwargs
    assert "stdout" not in kwargs
    assert "stdin" not in kwargs


@patch("bulkprovision.lrp_client.subprocess.run")
def test_login_returns_false_on_timeout(mock_run):
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="lrp login", timeout=LOGIN_TIMEOUT_SECONDS)
    assert login() is False
    # A timeout skips the --manual fallback entirely - a hang is a different
    # problem than a fast cert-trust failure, and doubling an already-stuck
    # wait isn't useful.
    assert mock_run.call_count == 1


@patch("bulkprovision.lrp_client.subprocess.run")
def test_login_force_passes_force_flag_to_browser_attempt(mock_run):
    mock_run.return_value = MagicMock(returncode=0)
    assert login(force=True) is True
    mock_run.assert_called_once_with(["lrp", "login", "--force"], timeout=LOGIN_TIMEOUT_SECONDS)


@patch("bulkprovision.lrp_client.subprocess.run")
def test_login_force_passes_force_flag_to_manual_fallback_too(mock_run):
    mock_run.side_effect = [MagicMock(returncode=1), MagicMock(returncode=0)]
    assert login(force=True) is True
    assert mock_run.call_count == 2
    first_call, second_call = mock_run.call_args_list
    assert first_call.args[0] == ["lrp", "login", "--force"]
    assert second_call.args[0] == ["lrp", "login", "--manual", "--force"]


@patch("bulkprovision.lrp_client.subprocess.run")
def test_login_falls_back_to_manual_when_browser_login_fails_fast(mock_run):
    mock_run.side_effect = [MagicMock(returncode=1), MagicMock(returncode=0)]
    assert login() is True
    assert mock_run.call_count == 2
    first_call, second_call = mock_run.call_args_list
    assert first_call.args[0] == ["lrp", "login"]
    assert second_call.args[0] == ["lrp", "login", "--manual"]


@patch("bulkprovision.lrp_client.subprocess.run")
def test_login_false_when_both_browser_and_manual_fail(mock_run):
    mock_run.side_effect = [MagicMock(returncode=1), MagicMock(returncode=1)]
    assert login() is False
    assert mock_run.call_count == 2


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_returns_single_match(mock_run):
    mock_run.return_value = _mock_completed({
        "total": 1,
        "items": [{"id": "x1", "name": "Asthana, Ankit", "email": "extern.asthana_ankit@allianz.de"}],
    })
    user = find_user("extern.asthana_ankit@allianz.de")
    assert user["id"] == "x1"
    mock_run.assert_called_once_with(
        ["lrp", "find-user", "extern.asthana_ankit@allianz.de", "-o", "json"],
        capture_output=True, text=True, timeout=LRP_TIMEOUT_SECONDS,
    )


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_raises_on_zero_matches(mock_run):
    mock_run.return_value = _mock_completed({"total": 0, "items": []})
    with pytest.raises(LrpError, match="USER_NOT_FOUND"):
        find_user("unknown@allianz.de")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_raises_on_multiple_matches(mock_run):
    mock_run.return_value = _mock_completed({"total": 2, "items": [{"id": "x1"}, {"id": "x2"}]})
    with pytest.raises(LrpError, match="AMBIGUOUS_USER"):
        find_user("common-name")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_narrows_multiple_matches_by_exact_email(mock_run):
    """lrp can return a personal account plus e.g. an M365 admin account for
    the same person - narrow to whichever one's email exactly matches the
    recipient string that was searched for, rather than erroring out."""
    mock_run.return_value = _mock_completed({
        "total": 2,
        "items": [
            {"id": "x1", "name": "Lakhpati, Sachin", "email": "sachin.lakhpati@allianz.com"},
            {"id": "x2", "name": "Lakhpati, Sachin - M365 Admin Account", "email": "adm_wgbh5c9@allianzms.onmicrosoft.com"},
        ],
    })
    user = find_user("sachin.lakhpati@allianz.com")
    assert user["id"] == "x1"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_still_ambiguous_when_multiple_emails_match_exactly(mock_run):
    mock_run.return_value = _mock_completed({
        "total": 2,
        "items": [
            {"id": "x1", "email": "shared@allianz.com"},
            {"id": "x2", "email": "shared@allianz.com"},
        ],
    })
    with pytest.raises(LrpError, match="AMBIGUOUS_USER"):
        find_user("shared@allianz.com")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_still_not_found_when_no_email_matches_exactly(mock_run):
    mock_run.return_value = _mock_completed({
        "total": 2,
        "items": [
            {"id": "x1", "email": "other1@allianz.com"},
            {"id": "x2", "email": "other2@allianz.com"},
        ],
    })
    with pytest.raises(LrpError, match="USER_NOT_FOUND"):
        find_user("sachin.lakhpati@allianz.com")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_rejects_single_result_with_non_matching_email(mock_run):
    """Real bug: lrp find-user can return exactly one result for an email
    search, but that result's own email is a completely different
    admin/service account (e.g. adm_xyz@allianzms.onmicrosoft.com) - a
    single result is not automatically trusted; the email must still match
    exactly, or this must fail loudly instead of silently acting on behalf
    of the wrong account."""
    mock_run.return_value = _mock_completed({
        "total": 1,
        "items": [{
            "id": "x1",
            "name": "Neve, Parimal (Allianz Technology SE) - M365 Admin Account",
            "email": "adm_i3ihp8g@allianzms.onmicrosoft.com",
        }],
    })
    with pytest.raises(LrpError, match="USER_NOT_FOUND"):
        find_user("PARIMAL.NEVE@ALLIANZ.COM")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_matches_by_name_suffix_when_email_field_is_blank(mock_run):
    """Real, confirmed case: M365 admin/service accounts have a completely
    blank `email` field in lrp find-user's response - the actual address
    only appears as a suffix of the display `name`. Searching that exact
    address returns exactly one result and the portal confirms it's the
    right account, so this must succeed via the name-suffix fallback rather
    than being rejected as not-found."""
    mock_run.return_value = _mock_completed({
        "total": 1,
        "items": [{
            "id": "x1",
            "name": "Lakhpati, Sachin (Allianz Technology SE) - M365 Admin Account - adm_wgbh5c9@allianzms.onmicrosoft.com",
            "email": "",
        }],
    })
    user = find_user("adm_wgbh5c9@allianzms.onmicrosoft.com")
    assert user["id"] == "x1"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_name_suffix_fallback_never_overrides_a_populated_different_email(mock_run):
    """The name-suffix fallback must only ever apply to accounts with a
    blank email - never to override a populated-but-different email, or it
    would defeat the entire point of requiring an exact match."""
    mock_run.return_value = _mock_completed({
        "total": 1,
        "items": [{
            "id": "x1",
            "name": "Some Account - adm_wgbh5c9@allianzms.onmicrosoft.com",
            "email": "someone.else@allianz.com",
        }],
    })
    with pytest.raises(LrpError, match="USER_NOT_FOUND"):
        find_user("adm_wgbh5c9@allianzms.onmicrosoft.com")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_not_found_error_shows_actual_field_values(mock_run):
    """When neither the email nor the name-suffix fallback matches, the
    error must show the actual email/name fields lrp returned, not just a
    bare "not found", so a mismatch is diagnosable without a separate
    manual `lrp find-user -o json` call."""
    mock_run.return_value = _mock_completed({
        "total": 1,
        "items": [{
            "id": "x1",
            "name": "Someone Else - completely-different@allianzms.onmicrosoft.com",
            "email": None,
        }],
    })
    with pytest.raises(LrpError) as exc_info:
        find_user("adm_wgbh5c9@allianzms.onmicrosoft.com")
    assert "email=None" in str(exc_info.value)
    assert "Someone Else" in str(exc_info.value)


@patch("bulkprovision.lrp_client.subprocess.run")
def test_find_user_raises_ambiguous_when_multiple_name_suffix_matches(mock_run):
    mock_run.return_value = _mock_completed({
        "total": 2,
        "items": [
            {"id": "x1", "name": "Account A - adm_wgbh5c9@allianzms.onmicrosoft.com", "email": ""},
            {"id": "x2", "name": "Account B - adm_wgbh5c9@allianzms.onmicrosoft.com", "email": ""},
        ],
    })
    with pytest.raises(LrpError, match="AMBIGUOUS_USER"):
        find_user("adm_wgbh5c9@allianzms.onmicrosoft.com")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_search_product_matches_by_exact_name(mock_run):
    mock_run.return_value = _mock_completed({
        "total": 2,
        "products": [
            {"productId": "CCC-1", "name": "APP-GITHUB-ADMIN"},
            {"productId": "CCC-2", "name": "APP-GITHUB-READ"},
        ],
    })
    product = search_product("APP-GITHUB-ADMIN")
    assert product["productId"] == "CCC-1"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_search_product_raises_when_no_exact_match(mock_run):
    mock_run.return_value = _mock_completed({"total": 1, "products": [{"productId": "CCC-1", "name": "APP-OTHER"}]})
    with pytest.raises(LrpError, match="PRODUCT_NOT_FOUND"):
        search_product("APP-GITHUB-ADMIN")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_run_raises_lrp_error_on_error_envelope(mock_run):
    mock_run.return_value = _mock_completed({"error": True, "code": "AUTH_EXPIRED", "message": "Session expired."})
    with pytest.raises(LrpError, match="AUTH_EXPIRED"):
        find_user("extern.asthana_ankit@allianz.de")


@patch("bulkprovision.lrp_client.subprocess.run")
def test_add_to_cart_forces_is_added_to_cart_false(mock_run):
    mock_run.return_value = _mock_completed({"total": 1, "items": []})
    add_to_cart([{"productId": "CCC-1", "name": "APP-GITHUB-ADMIN", "isAddedToCart": True}])
    called_args = mock_run.call_args[0][0]
    products_json = called_args[called_args.index("--products") + 1]
    assert json.loads(products_json)[0]["isAddedToCart"] is False


@patch("bulkprovision.lrp_client.subprocess.run")
def test_get_cart_returns_items(mock_run):
    mock_run.return_value = _mock_completed({"total": 1, "items": [{"cartItemId": "1"}], "error": False})
    cart = get_cart()
    assert cart["items"][0]["cartItemId"] == "1"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_submit_cart_passes_through_warning_result_without_raising(mock_run):
    mock_run.return_value = _mock_completed({
        "result": "warning",
        "message": "WARNING_ONE_ON_BEHALF_SOME_DUPLICATES",
        "nonRequestableProducts": {"Z4QTV6A": [{"name": "APP-GITHUB-READ"}]},
    })
    response = submit_cart(items=[{"cartItemId": "1"}], reason="Onboarding", on_behalf_of={"id": "u1"})
    assert response["result"] == "warning"
    assert response["nonRequestableProducts"]["Z4QTV6A"][0]["name"] == "APP-GITHUB-READ"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_submit_cart_returns_error_result_without_raising(mock_run):
    mock_run.return_value = _mock_completed({"result": "error", "message": "ERROR_ORDER_FAILED"})
    response = submit_cart(items=[{"cartItemId": "1"}], reason="x", on_behalf_of={"id": "u1"})
    assert response["result"] == "error"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_order_product_forces_is_added_to_cart_false(mock_run):
    mock_run.return_value = _mock_completed({"result": "success", "message": "SUCCESS"})
    order_product({"productId": "CCC-1", "name": "APP-GITHUB-ADMIN", "isAddedToCart": True}, "Onboarding", {"id": "u1"})
    called_args = mock_run.call_args[0][0]
    product_json = called_args[called_args.index("--product") + 1]
    assert json.loads(product_json)["isAddedToCart"] is False


@patch("bulkprovision.lrp_client.subprocess.run")
def test_order_product_passes_on_behalf_of_when_given(mock_run):
    mock_run.return_value = _mock_completed({"result": "success", "message": "SUCCESS"})
    order_product({"productId": "CCC-1", "name": "APP-GITHUB-ADMIN"}, "Onboarding", {"id": "u1"})
    called_args = mock_run.call_args[0][0]
    assert "--on-behalf-of" in called_args
    on_behalf_of_json = called_args[called_args.index("--on-behalf-of") + 1]
    assert json.loads(on_behalf_of_json) == {"id": "u1"}


@patch("bulkprovision.lrp_client.subprocess.run")
def test_order_product_omits_on_behalf_of_when_none(mock_run):
    mock_run.return_value = _mock_completed({"result": "success", "message": "SUCCESS"})
    order_product({"productId": "CCC-1", "name": "APP-GITHUB-ADMIN"}, "Onboarding", None)
    called_args = mock_run.call_args[0][0]
    assert "--on-behalf-of" not in called_args


@patch("bulkprovision.lrp_client.subprocess.run")
def test_order_product_passes_through_warning_result_without_raising(mock_run):
    mock_run.return_value = _mock_completed({
        "result": "warning",
        "message": "WARNING_ONE_ON_BEHALF_SOME_DUPLICATES",
        "nonRequestableProducts": {"Z4QTV6A": [{"name": "APP-GITHUB-READ"}]},
    })
    response = order_product({"productId": "CCC-2", "name": "APP-GITHUB-READ"}, "Onboarding", {"id": "u1"})
    assert response["result"] == "warning"
    assert response["nonRequestableProducts"]["Z4QTV6A"][0]["name"] == "APP-GITHUB-READ"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_order_product_returns_error_result_without_raising(mock_run):
    mock_run.return_value = _mock_completed({"result": "error", "message": "ERROR_ORDER_FAILED"})
    response = order_product({"productId": "CCC-1", "name": "APP-GITHUB-ADMIN"}, "x", {"id": "u1"})
    assert response["result"] == "error"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_list_orders_returns_product_requests(mock_run):
    mock_run.return_value = _mock_completed({
        "total": 1, "productRequests": [{"requestKey": "r1", "status": "Pending"}], "error": False,
    })
    orders = list_orders()
    assert orders[0]["status"] == "Pending"


@patch("bulkprovision.lrp_client.subprocess.run")
def test_get_cart_passes_through_degraded_response_without_raising(mock_run):
    """Test that response-level error flag (no 'code') passes through without raising.

    This happens when backend OID calls degrade: {"error": true, "total": 0, "items": []}
    (no 'code'/'message' keys) should be returned as normal data, not mistaken for a
    generic CLI-level error envelope (which always has 'code').
    """
    mock_run.return_value = _mock_completed({"error": True, "total": 0, "items": []})
    cart = get_cart()
    assert cart["error"] is True
    assert cart["total"] == 0
    assert cart["items"] == []


@patch("bulkprovision.lrp_client.subprocess.run")
def test_run_raises_lrp_error_on_non_json_stdout(mock_run):
    completed = MagicMock()
    completed.stdout = "Warning: proxy in use\n<html>Access denied</html>"
    completed.stderr = ""
    completed.returncode = 0
    mock_run.return_value = completed

    with pytest.raises(LrpError, match="INVALID_JSON"):
        get_cart()


@patch("bulkprovision.lrp_client.subprocess.run")
def test_run_raises_lrp_error_on_timeout(mock_run):
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="lrp", timeout=LRP_TIMEOUT_SECONDS)

    with pytest.raises(LrpError, match="TIMEOUT"):
        get_cart()


@patch("bulkprovision.lrp_client.subprocess.run")
def test_check_auth_returns_false_on_timeout(mock_run):
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="lrp", timeout=LRP_TIMEOUT_SECONDS)

    assert check_auth() is False


@patch("bulkprovision.lrp_client.subprocess.run")
def test_every_command_passes_a_timeout(mock_run):
    mock_run.return_value = _mock_completed({"total": 0, "items": [], "products": [], "productRequests": []})
    for call in (
        lambda: get_cart(),
        lambda: list_orders(),
        lambda: add_to_cart([{"productId": "CCC-1", "name": "APP-X"}]),
        lambda: submit_cart(items=[], reason="x", on_behalf_of={"id": "u1"}),
        lambda: order_product({"productId": "CCC-1", "name": "APP-X"}, "x", {"id": "u1"}),
    ):
        mock_run.reset_mock()
        call()
        assert mock_run.call_args.kwargs["timeout"] == LRP_TIMEOUT_SECONDS
