import csv
import json

import openpyxl

from bulkprovision.cli import main
from bulkprovision.lrp_client import LrpError


def _write_workbook(path, header, rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(header)
    for row in rows:
        ws.append(row)
    wb.save(path)


class FakeClient:
    def check_auth(self):
        return True

    def login(self):
        return True

    def find_user(self, recipient):
        return {"id": "u1", "name": "Test User", "email": recipient}

    def search_product(self, group_name):
        return {"productId": "CCC-1", "name": group_name}

    def order_product(self, product, reason, on_behalf_of):
        return {"result": "success", "message": "SUCCESS"}


def _args(tmp_path, input_path, run_id="run-1"):
    return [
        "--input", str(input_path),
        "--report", str(tmp_path / "report.csv"),
        "--retry-out", str(tmp_path / "retry.json"),
        "--run-id", run_id,
        # Tests care about the deterministic pipeline, not the AI summary -
        # skip it so the suite never shells out to a real `claude` binary
        # (which may or may not be installed wherever tests run).
        "--no-ai-summary",
    ]


def test_main_end_to_end_writes_report_and_retry_store(tmp_path):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(
        input_path,
        ["recipient", "giam_group", "justification"],
        [
            ["extern.asthana_ankit@allianz.de", "APP-GITHUB-ADMIN", "Onboarding"],
            ["extern.asthana_ankit@allianz.de", "APP-RETIRED-ROLE", "Onboarding"],
        ],
    )

    class ClientWithOneMissingProduct(FakeClient):
        def search_product(self, group_name):
            if group_name == "APP-RETIRED-ROLE":
                raise LrpError("PRODUCT_NOT_FOUND", f"'{group_name}' not found")
            return super().search_product(group_name)

    exit_code = main(
        _args(tmp_path, input_path),
        client=ClientWithOneMissingProduct(),
        ensure_installed=lambda: True,
    )

    # There's no separate catalogue pre-check anymore - `lrp search-products`
    # itself is the validation. A group it can't find becomes an `error` row
    # (exit code 1), not a `rejected` one, but the recipient's other, valid
    # group still gets submitted.
    assert exit_code == 1
    with open(tmp_path / "report.csv", newline="") as f:
        rows = list(csv.DictReader(f))
    statuses = {(r["giam_group"], r["status"]) for r in rows}
    assert ("APP-GITHUB-ADMIN", "submitted") in statuses
    assert ("APP-RETIRED-ROLE", "error") in statuses

    retry_payload = json.loads((tmp_path / "retry.json").read_text())
    assert retry_payload["run_id"] == "run-1"
    assert retry_payload["rows"] == [
        {"recipient": "extern.asthana_ankit@allianz.de", "giam_group": "APP-RETIRED-ROLE", "reason": "'APP-RETIRED-ROLE' not found"}
    ]


def test_main_prints_live_per_row_progress_before_final_summary(tmp_path, capsys):
    """Operators shouldn't have to wait in silence for the whole batch - each
    row's outcome must print as soon as it's known, not just in the final
    summary line."""
    input_path = tmp_path / "input.xlsx"
    _write_workbook(
        input_path,
        ["recipient", "giam_group", "justification"],
        [
            [None, "APP-GITHUB-ADMIN", "Onboarding"],
            ["a@b.com", "APP-GITHUB-ADMIN", "Onboarding"],
        ],
    )

    exit_code = main(
        _args(tmp_path, input_path, run_id="run-progress"),
        client=FakeClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 0
    out = capsys.readouterr().out
    lines = [line for line in out.splitlines() if line.startswith("[")]
    assert lines == [
        "[1/2] row 1 (missing recipient) | row 1 (missing recipient) | rejected | Input row 1 could not be processed: missing recipient",
        "[2/2] a@b.com | APP-GITHUB-ADMIN | submitted | Order submitted successfully.",
    ]
    # The final summary line must still come after all per-row progress lines.
    assert out.index("Processed 2 rows") > out.index("[2/2]")


def test_main_returns_exit_code_1_when_errors_occur(tmp_path):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    class ErroringClient(FakeClient):
        def find_user(self, recipient):
            raise LrpError("USER_NOT_FOUND", "no match")

    exit_code = main(
        _args(tmp_path, input_path, run_id="run-2"),
        client=ErroringClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 1
    retry_payload = json.loads((tmp_path / "retry.json").read_text())
    assert retry_payload["rows"] == [{"recipient": "a@b.com", "giam_group": "APP-GITHUB-ADMIN", "reason": "no match"}]


def test_main_reports_rows_with_missing_recipient_as_rejected(tmp_path):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(
        input_path,
        ["recipient", "giam_group", "justification"],
        [
            ["a@b.com", "APP-GITHUB-ADMIN", "Onboarding"],
            [None, "APP-GITHUB-ADMIN", "Onboarding"],
        ],
    )

    exit_code = main(
        _args(tmp_path, input_path, run_id="run-9"),
        client=FakeClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 0
    with open(tmp_path / "report.csv", newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    # Every input row is accounted for: one submitted, one rejected.
    assert len(rows) == 2
    rejected = [r for r in rows if r["status"] == "rejected"]
    assert len(rejected) == 1
    assert "missing recipient" in rejected[0]["message"]
    assert "row 2" in rejected[0]["recipient"]


def test_main_returns_exit_code_5_on_unexpected_exception(tmp_path, capsys):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    class CrashingClient(FakeClient):
        def find_user(self, recipient):
            raise RuntimeError("kaboom")

    exit_code = main(
        _args(tmp_path, input_path, run_id="run-7"),
        client=CrashingClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 5
    stderr = capsys.readouterr().err
    assert "Unexpected error during processing/reporting" in stderr
    assert "kaboom" in stderr


def test_main_writes_report_into_a_missing_output_directory(tmp_path):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    out_dir = tmp_path / "out" / "run"
    exit_code = main(
        [
            "--input", str(input_path),
            "--report", str(out_dir / "report.csv"),
            "--retry-out", str(out_dir / "retry.json"),
            "--run-id", "run-8",
            "--no-ai-summary",
        ],
        client=FakeClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 0
    assert (out_dir / "report.csv").exists()
    assert (out_dir / "retry.json").exists()


def test_main_returns_exit_code_2_when_not_authenticated(tmp_path):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    class NotAuthedClient(FakeClient):
        def check_auth(self):
            return False

    exit_code = main(
        _args(tmp_path, input_path, run_id="run-3"),
        client=NotAuthedClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 2
    assert not (tmp_path / "report.csv").exists()


def test_main_auto_logs_in_when_not_authenticated_then_proceeds(tmp_path):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    class LogsInOnDemandClient(FakeClient):
        def __init__(self):
            self.authenticated = False
            self.login_called = False

        def check_auth(self):
            return self.authenticated

        def login(self):
            self.login_called = True
            self.authenticated = True
            return True

    client = LogsInOnDemandClient()
    exit_code = main(
        _args(tmp_path, input_path, run_id="run-auto-login"),
        client=client,
        ensure_installed=lambda: True,
    )

    assert client.login_called is True
    assert exit_code == 0
    assert (tmp_path / "report.csv").exists()


def test_main_returns_exit_code_2_when_login_itself_fails(tmp_path):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    class LoginFailsClient(FakeClient):
        def check_auth(self):
            return False

        def login(self):
            return False

    exit_code = main(
        _args(tmp_path, input_path, run_id="run-login-fails"),
        client=LoginFailsClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 2
    assert not (tmp_path / "report.csv").exists()


def test_main_returns_exit_code_3_when_lrp_not_installed(tmp_path):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    exit_code = main(
        _args(tmp_path, input_path, run_id="run-4"),
        client=FakeClient(),
        ensure_installed=lambda: False,
    )

    assert exit_code == 3
    assert not (tmp_path / "report.csv").exists()


def test_main_returns_exit_code_4_when_input_excel_is_malformed(tmp_path):
    input_path = tmp_path / "input.xlsx"
    # Missing the required giam_group column.
    _write_workbook(input_path, ["recipient", "justification"], [["a@b.com", "x"]])

    exit_code = main(
        _args(tmp_path, input_path, run_id="run-5"),
        client=FakeClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 4
    assert not (tmp_path / "report.csv").exists()
    assert not (tmp_path / "retry.json").exists()


def test_main_prints_ai_summary_when_generated(tmp_path, capsys):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    args = _args(tmp_path, input_path, run_id="run-ai-1")
    args.remove("--no-ai-summary")

    exit_code = main(
        args,
        client=FakeClient(),
        ensure_installed=lambda: True,
        generate_summary=lambda results: "## Summary\n\nAll 1 request submitted successfully.",
    )

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "AI-generated summary" in captured.out
    assert "All 1 request submitted successfully." in captured.out


def test_main_skips_ai_summary_generation_when_flag_set(tmp_path, capsys):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    called = []

    exit_code = main(
        _args(tmp_path, input_path, run_id="run-ai-2"),  # includes --no-ai-summary
        client=FakeClient(),
        ensure_installed=lambda: True,
        generate_summary=lambda results: called.append(results) or "should not be printed",
    )

    assert exit_code == 0
    assert called == []
    captured = capsys.readouterr()
    assert "AI-generated summary" not in captured.out


def test_main_prints_nothing_extra_when_ai_summary_returns_none(tmp_path, capsys):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    args = _args(tmp_path, input_path, run_id="run-ai-3")
    args.remove("--no-ai-summary")

    exit_code = main(
        args,
        client=FakeClient(),
        ensure_installed=lambda: True,
        generate_summary=lambda results: None,
    )

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "AI-generated summary" not in captured.out


def test_main_ai_summary_error_does_not_affect_exit_code_or_crash(tmp_path, capsys):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    args = _args(tmp_path, input_path, run_id="run-ai-4")
    args.remove("--no-ai-summary")

    def broken_summary(results):
        raise RuntimeError("simulated bug in ai_summary")

    exit_code = main(
        args,
        client=FakeClient(),
        ensure_installed=lambda: True,
        generate_summary=broken_summary,
    )

    assert exit_code == 0
    assert (tmp_path / "report.csv").exists()
    captured = capsys.readouterr()
    assert "AI summary skipped" in captured.err


def test_main_returns_exit_code_4_when_input_file_does_not_exist(tmp_path):
    input_path = tmp_path / "does-not-exist.xlsx"

    exit_code = main(
        _args(tmp_path, input_path, run_id="run-6"),
        client=FakeClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 4
    assert not (tmp_path / "report.csv").exists()
    assert not (tmp_path / "retry.json").exists()


def test_main_returns_exit_code_6_when_input_given_without_other_required_batch_args(tmp_path):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    exit_code = main(
        ["--input", str(input_path)],  # missing --report/--retry-out/--run-id
        client=FakeClient(),
        ensure_installed=lambda: True,
    )

    assert exit_code == 6


def test_main_launches_interactive_menu_when_no_input_given(tmp_path):
    calls = []

    def fake_menu(client, generate_summary, run_batch, input_func, print_func):
        calls.append((client, generate_summary, run_batch))
        return 0

    import bulkprovision.cli as cli_module
    original = cli_module.run_interactive_menu
    cli_module.run_interactive_menu = fake_menu
    try:
        exit_code = main([], client=FakeClient(), ensure_installed=lambda: True)
    finally:
        cli_module.run_interactive_menu = original

    assert exit_code == 0
    assert len(calls) == 1


def test_main_launches_interactive_menu_when_interactive_flag_given_even_with_batch_args(tmp_path):
    input_path = tmp_path / "input.xlsx"
    _write_workbook(input_path, ["recipient", "giam_group", "justification"], [["a@b.com", "APP-GITHUB-ADMIN", "x"]])

    calls = []

    def fake_menu(client, generate_summary, run_batch, input_func, print_func):
        calls.append(True)
        return 0

    import bulkprovision.cli as cli_module
    original = cli_module.run_interactive_menu
    cli_module.run_interactive_menu = fake_menu
    try:
        exit_code = main(
            _args(tmp_path, input_path, run_id="run-7") + ["--interactive"],
            client=FakeClient(),
            ensure_installed=lambda: True,
        )
    finally:
        cli_module.run_interactive_menu = original

    assert exit_code == 0
    assert calls == [True]
    # Interactive mode was used instead of batch mode - no report should exist.
    assert not (tmp_path / "report.csv").exists()
