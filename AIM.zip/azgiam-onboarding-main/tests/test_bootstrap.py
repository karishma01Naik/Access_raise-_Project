import subprocess
from unittest.mock import MagicMock

from bulkprovision.bootstrap import (
    ensure_lrp_installed, INSTALL_SCRIPT_URL, INSTALL_TIMEOUT_SECONDS,
)


def test_ensure_lrp_installed_skips_install_when_already_present():
    which = MagicMock(return_value="/home/user/.local/bin/lrp")
    run = MagicMock()

    result = ensure_lrp_installed(run=run, which=which)

    assert result is True
    run.assert_not_called()


def test_ensure_lrp_installed_runs_install_script_when_missing():
    which = MagicMock(side_effect=[None, "/home/user/.local/bin/lrp"])
    run = MagicMock(return_value=MagicMock(returncode=0))

    result = ensure_lrp_installed(run=run, which=which)

    assert result is True
    run.assert_called_once()
    command = run.call_args[0][0]
    assert INSTALL_SCRIPT_URL in command
    assert run.call_args.kwargs["timeout"] == INSTALL_TIMEOUT_SECONDS


def test_ensure_lrp_installed_returns_false_when_install_times_out():
    which = MagicMock(return_value=None)
    run = MagicMock(side_effect=subprocess.TimeoutExpired(cmd="curl", timeout=INSTALL_TIMEOUT_SECONDS))

    assert ensure_lrp_installed(run=run, which=which) is False


def test_ensure_lrp_installed_returns_false_when_install_fails():
    which = MagicMock(return_value=None)
    run = MagicMock(return_value=MagicMock(returncode=1))

    result = ensure_lrp_installed(run=run, which=which)

    assert result is False
