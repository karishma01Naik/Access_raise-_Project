from bulkprovision.io_excel import InputRow
from bulkprovision.lrp_client import LrpError
from bulkprovision.orchestrator import (
    RESULT_MESSAGES, RowResult, humanize, process_recipient, process_all,
)


class FakeClient:
    def __init__(self):
        self.user = {"id": "u1", "name": "Asthana, Ankit", "email": "extern.asthana_ankit@allianz.de"}
        self.products = {
            "APP-GITHUB-ADMIN": {"productId": "CCC-1", "name": "APP-GITHUB-ADMIN"},
            "APP-GITHUB-READ": {"productId": "CCC-2", "name": "APP-GITHUB-READ"},
        }
        self.order_response = {"result": "success", "message": "SUCCESS"}
        self.order_calls = []

    def find_user(self, recipient):
        return self.user

    def search_product(self, group_name):
        return self.products[group_name]

    def order_product(self, product, reason, on_behalf_of):
        self.order_calls.append({"product": product, "reason": reason, "on_behalf_of": on_behalf_of})
        return self.order_response


def test_process_recipient_submits_all_valid_groups():
    rows = [
        InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="Onboarding"),
        InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="Onboarding"),
    ]
    client = FakeClient()

    results = process_recipient("Q1", rows, client=client)

    assert len(results) == 2
    assert all(r.status == "submitted" for r in results)
    # One order-product call per row, on behalf of the resolved user, no cart involved.
    assert [c["product"]["productId"] for c in client.order_calls] == ["CCC-1", "CCC-2"]
    assert all(c["on_behalf_of"] == client.user for c in client.order_calls)


def test_process_recipient_marks_error_when_user_not_found():
    rows = [InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x")]
    client = FakeClient()

    def raise_not_found(recipient):
        raise LrpError("USER_NOT_FOUND", "no match")

    client.find_user = raise_not_found

    results = process_recipient("Q1", rows, client=client)

    assert results == [RowResult("Q1", "APP-GITHUB-ADMIN", "error", "no match")]


def test_process_recipient_marks_error_for_missing_product_but_continues_others():
    rows = [
        InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x"),
        InputRow(recipient="Q1", giam_group="APP-UNKNOWN", justification="x"),
    ]
    client = FakeClient()

    def search(group_name):
        if group_name not in client.products:
            raise LrpError("PRODUCT_NOT_FOUND", f"'{group_name}' not found")
        return client.products[group_name]

    client.search_product = search

    results = process_recipient("Q1", rows, client=client)

    by_group = {r.giam_group: r for r in results}
    assert by_group["APP-GITHUB-ADMIN"].status == "submitted"
    assert by_group["APP-UNKNOWN"].status == "error"
    assert "not found" in by_group["APP-UNKNOWN"].message


def test_process_recipient_flags_warning_for_non_requestable_products():
    rows = [InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="x")]
    client = FakeClient()
    client.order_response = {
        "result": "warning",
        "message": "WARNING_ONE_ON_BEHALF_SOME_DUPLICATES",
        "nonRequestableProducts": {"Z4QTV6A": [{"name": "APP-GITHUB-READ"}]},
    }

    results = process_recipient("Q1", rows, client=client)

    assert results[0].status == "warning"
    assert "already submitted/assigned previously" in results[0].message
    assert "already assigned or requested" in results[0].message  # original lrp detail retained


def test_process_all_groups_by_recipient():
    rows = [
        InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x"),
        InputRow(recipient="Q2", giam_group="APP-GITHUB-READ", justification="x"),
    ]
    client = FakeClient()

    results = process_all(rows, client=client)

    assert {r.recipient for r in results} == {"Q1", "Q2"}


def test_process_recipient_calls_on_result_as_each_row_completes():
    rows = [
        InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x"),
        InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="x"),
    ]
    client = FakeClient()
    seen = []

    results = process_recipient("Q1", rows, client=client, on_result=seen.append)

    assert seen == results
    assert [r.giam_group for r in seen] == ["APP-GITHUB-ADMIN", "APP-GITHUB-READ"]


def test_process_all_calls_on_result_across_recipients():
    rows = [
        InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x"),
        InputRow(recipient="Q2", giam_group="APP-GITHUB-READ", justification="x"),
    ]
    client = FakeClient()
    seen = []

    results = process_all(rows, client=client, on_result=seen.append)

    assert seen == results
    assert {r.recipient for r in seen} == {"Q1", "Q2"}


def test_process_recipient_marks_error_when_order_product_raises():
    rows = [
        InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x"),
        InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="x"),
    ]
    client = FakeClient()

    def raise_on_order(product, reason, on_behalf_of):
        raise LrpError("SUBMIT_FAILED", "order submission failed")

    client.order_product = raise_on_order

    results = process_recipient("Q1", rows, client=client)

    assert len(results) == 2
    assert all(r.status == "error" for r in results)
    assert all(r.message == "order submission failed" for r in results)


def test_process_recipient_marks_all_duplicates_as_warning_not_error():
    rows = [InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="x")]
    client = FakeClient()
    client.order_response = {
        "result": "error",
        "message": "ERROR_ONE_ON_BEHALF_ALL_DUPLICATES",
        "nonRequestableProducts": {"Z4QTV6A": [{"name": "APP-GITHUB-READ"}]},
    }

    results = process_recipient("Q1", rows, client=client)

    assert results[0].status == "warning"
    assert "already submitted/assigned previously" in results[0].message


def test_humanize_known_key_and_fallback():
    assert humanize("SUCCESS") == "Order submitted successfully."
    assert humanize("SOME_NEW_KEY") == "SOME_NEW_KEY"


def test_process_recipient_one_row_failing_does_not_affect_others():
    """order-product is a single, independent call per row - a failure on
    one row must never affect any other row for the same recipient (unlike
    the old cart flow, where one add-to-cart call covered every row)."""
    rows = [
        InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x"),
        InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="x"),
    ]
    client = FakeClient()
    responses = {
        "CCC-1": {"result": "error", "message": "ERROR_ORDER_FAILED"},
        "CCC-2": {"result": "success", "message": "SUCCESS"},
    }

    def order_product(product, reason, on_behalf_of):
        return responses[product["productId"]]

    client.order_product = order_product

    results = process_recipient("Q1", rows, client=client)

    by_group = {r.giam_group: r for r in results}
    assert by_group["APP-GITHUB-ADMIN"].status == "error"
    assert by_group["APP-GITHUB-READ"].status == "submitted"


def test_process_recipient_falls_back_when_order_response_has_no_message():
    rows = [InputRow(recipient="Q1", giam_group="APP-GITHUB-ADMIN", justification="x")]
    client = FakeClient()
    client.order_response = {"result": "error"}

    results = process_recipient("Q1", rows, client=client)

    assert results[0].status == "error"
    assert results[0].message
    assert results[0].message == "lrp returned no error message for this outcome"


def test_duplicate_match_is_case_and_whitespace_insensitive():
    rows = [InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="x")]
    client = FakeClient()
    client.order_response = {
        "result": "error",
        "message": "ERROR_ORDER_FAILED",
        "nonRequestableProducts": {"Z4QTV6A": [{"name": "  app-github-read "}]},
    }

    results = process_recipient("Q1", rows, client=client)

    assert results[0].status == "warning"


def test_duplicate_match_by_product_id_when_name_is_missing():
    rows = [InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="x")]
    client = FakeClient()
    client.order_response = {
        "result": "error",
        "message": "ERROR_ORDER_FAILED",
        "nonRequestableProducts": {"Z4QTV6A": [{"name": "", "productId": "CCC-2"}]},
    }

    results = process_recipient("Q1", rows, client=client)

    assert results[0].status == "warning"


def test_duplicate_flavoured_message_key_downgrades_error_to_warning():
    rows = [InputRow(recipient="Q1", giam_group="APP-GITHUB-READ", justification="x")]
    client = FakeClient()
    client.order_response = {
        "result": "error",
        "message": "ERROR_SOME_FUTURE_DUPLICATE_VARIANT",
        # No nonRequestableProducts at all - only the message hints at duplicates.
    }

    results = process_recipient("Q1", rows, client=client)

    assert results[0].status == "warning"
    assert "already submitted/assigned previously" in results[0].message


def test_verbatim_result_messages_match_lrp_cli():
    assert RESULT_MESSAGES["ERROR_ONE_ON_BEHALF_DUPLICATE"] == (
        "The recipient already has (or has already requested) this product, so it was not ordered."
    )
    assert RESULT_MESSAGES["ERROR_GENERAL"] == "The order completed with errors."
    assert RESULT_MESSAGES["WARNING_SELF_SOME_DUPLICATES"] == (
        "Some products were already assigned or requested for you and were skipped; the rest were ordered."
    )
    assert RESULT_MESSAGES["ERROR_DUPLICATES_UNKNOWN"] == (
        "The order could not be completed due to an unresolved duplicate check."
    )
