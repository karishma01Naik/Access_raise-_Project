from bulkprovision.interactive import _format_order, _format_product, _format_status, _format_user, run_interactive_menu
from bulkprovision.lrp_client import LrpError


def _scripted_input(responses):
    queue = list(responses)

    def _input(prompt=""):
        if not queue:
            raise EOFError("scripted input exhausted")
        return queue.pop(0)

    return _input


def _recording_print():
    lines = []

    def _print(*args, **kwargs):
        lines.append(" ".join(str(a) for a in args))

    _print.lines = lines
    return _print


class FakeClient:
    def __init__(self):
        self.authenticated = True
        self.login_called = False
        self.find_user_calls = []
        self.search_product_calls = []

    def check_auth(self):
        return self.authenticated

    def login(self, force=False):
        self.login_called = True
        self.login_forced = force
        return True

    def find_user(self, recipient):
        self.find_user_calls.append(recipient)
        return {"id": "u1", "name": "Test User", "email": recipient}

    def search_product(self, query):
        self.search_product_calls.append(query)
        if query == "UNKNOWN":
            raise LrpError("PRODUCT_NOT_FOUND", f"'{query}' not found")
        return {"productId": "CCC-1", "name": query}

    def list_orders(self):
        return [{"title": "APP-GITHUB-ADMIN", "status": "Pending", "requestKey": "r1", "createdDate": "2026-08-20"}]


def test_exits_immediately_on_choice_7():
    print_func = _recording_print()
    exit_code = run_interactive_menu(
        client=FakeClient(), generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["7"]), print_func=print_func,
    )
    assert exit_code == 0
    assert any("Goodbye" in line for line in print_func.lines)


def test_exits_on_eof_without_crashing():
    print_func = _recording_print()
    exit_code = run_interactive_menu(
        client=FakeClient(), generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input([]), print_func=print_func,
    )
    assert exit_code == 0


def test_check_auth_option_reports_authenticated():
    print_func = _recording_print()
    client = FakeClient()
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["2", "7"]), print_func=print_func,
    )
    assert any("Authenticated" in line for line in print_func.lines)


def test_check_auth_option_reports_not_authenticated():
    print_func = _recording_print()
    client = FakeClient()
    client.authenticated = False
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["2", "7"]), print_func=print_func,
    )
    assert any("Not authenticated" in line for line in print_func.lines)


def test_login_option_calls_client_login():
    print_func = _recording_print()
    client = FakeClient()
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["3", "7"]), print_func=print_func,
    )
    assert client.login_called is True
    assert client.login_forced is True  # explicit "Log in" must never trust a stale cached cookie
    assert any("Login succeeded" in line for line in print_func.lines)


def test_find_user_option_prompts_and_calls_client():
    print_func = _recording_print()
    client = FakeClient()
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["4", "extern.asthana_ankit@allianz.de", "7"]), print_func=print_func,
    )
    assert client.find_user_calls == ["extern.asthana_ankit@allianz.de"]
    assert any("Found:" in line for line in print_func.lines)


def test_find_user_option_requires_non_empty_input():
    print_func = _recording_print()
    client = FakeClient()
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["4", "", "7"]), print_func=print_func,
    )
    assert client.find_user_calls == []
    assert any("required" in line for line in print_func.lines)


def test_search_product_option_reports_lrp_error():
    print_func = _recording_print()
    client = FakeClient()
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["5", "UNKNOWN", "7"]), print_func=print_func,
    )
    assert client.search_product_calls == ["UNKNOWN"]
    assert any("Error:" in line and "not found" in line for line in print_func.lines)


def test_search_product_option_reports_success():
    print_func = _recording_print()
    client = FakeClient()
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["5", "APP-GITHUB-ADMIN", "7"]), print_func=print_func,
    )
    assert any("Found:" in line for line in print_func.lines)


def test_list_orders_option_prints_each_order():
    print_func = _recording_print()
    client = FakeClient()
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["6", "7"]), print_func=print_func,
    )
    assert any("APP-GITHUB-ADMIN" in line and "Pending" in line for line in print_func.lines)


def test_list_orders_option_handles_real_object_shaped_status():
    """lrp's real list-orders response has status as an object like
    {'Value': 'Assigned', 'IsReadOnly': True}, not a plain string - the
    docs undersell this. Must not print a raw Python dict repr."""
    print_func = _recording_print()
    client = FakeClient()
    client.list_orders = lambda: [{
        "title": "AWS-ReadOnly-Subscription-662403251356",
        "status": {"Value": "Aborted", "IsReadOnly": True, "DisplayValue": "Canceled"},
        "requestKey": "r1",
        "createdDate": "2026-08-20T11:33:59.343Z",
    }]
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["6", "7"]), print_func=print_func,
    )
    assert any("Canceled" in line for line in print_func.lines)
    assert not any("DisplayValue" in line for line in print_func.lines)


def test_format_status_prefers_display_value_over_value():
    assert _format_status({"Value": "Assigned", "IsReadOnly": True}) == "Assigned"
    assert _format_status({"Value": "Aborted", "DisplayValue": "Canceled"}) == "Canceled"
    assert _format_status("Pending") == "Pending"
    assert _format_status(None) == "?"


def test_format_user_and_product_do_not_dump_raw_dict():
    user_line = _format_user({"id": "u1", "name": "Ankit Asthana", "email": "a@b.com"})
    assert "Ankit Asthana" in user_line
    assert "a@b.com" in user_line
    assert "{" not in user_line

    product_line = _format_product({"productId": "CCC-1", "name": "AWS-ReadOnly", "description": "AWS Group ReadOnly"})
    assert "AWS-ReadOnly" in product_line
    assert "AWS Group ReadOnly" in product_line
    assert "{" not in product_line


def test_format_order_aligns_columns():
    line = _format_order({"title": "APP-X", "status": "Pending", "createdDate": "2026-01-01"})
    assert "APP-X" in line
    assert "Pending" in line
    assert "2026-01-01" in line


def test_list_orders_option_reports_no_orders():
    print_func = _recording_print()
    client = FakeClient()
    client.list_orders = lambda: []
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["6", "7"]), print_func=print_func,
    )
    assert any("No orders found" in line for line in print_func.lines)


def test_run_batch_option_prompts_for_path_and_invokes_run_batch():
    print_func = _recording_print()
    client = FakeClient()
    captured = {}

    def fake_run_batch(input_path, report_path, retry_path, run_id, client_arg, generate_summary_arg):
        captured["input_path"] = input_path
        captured["report_path"] = report_path
        captured["retry_path"] = retry_path
        captured["run_id"] = run_id
        return 0

    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=fake_run_batch,
        input_func=_scripted_input(["1", "in.xlsx", "7"]), print_func=print_func,
    )

    assert captured["input_path"] == "in.xlsx"
    assert captured["report_path"].startswith("report-")
    assert captured["retry_path"].startswith("retry-")
    assert any("exit code 0" in line for line in print_func.lines)


def test_run_batch_option_requires_a_path():
    print_func = _recording_print()
    client = FakeClient()
    called = []

    run_interactive_menu(
        client=client, generate_summary=lambda r: None,
        run_batch=lambda *a, **kw: called.append(a) or 0,
        input_func=_scripted_input(["1", "", "7"]), print_func=print_func,
    )

    assert called == []
    assert any("required" in line for line in print_func.lines)


def test_unknown_choice_reports_and_reloops():
    print_func = _recording_print()
    client = FakeClient()
    run_interactive_menu(
        client=client, generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
        input_func=_scripted_input(["99", "7"]), print_func=print_func,
    )
    assert any("Unknown choice" in line for line in print_func.lines)


def test_quit_synonyms_exit_cleanly():
    for word in ("q", "quit", "exit", "Q", "EXIT"):
        print_func = _recording_print()
        exit_code = run_interactive_menu(
            client=FakeClient(), generate_summary=lambda r: None, run_batch=lambda *a, **kw: 0,
            input_func=_scripted_input([word]), print_func=print_func,
        )
        assert exit_code == 0
