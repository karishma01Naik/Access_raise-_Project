import openpyxl
import pytest

from bulkprovision.io_excel import read_input_rows, InputRow


def _write_workbook(path, header, rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(header)
    for row in rows:
        ws.append(row)
    wb.save(path)


def test_read_input_rows_parses_valid_rows(tmp_path):
    path = tmp_path / "input.xlsx"
    _write_workbook(
        path,
        ["recipient", "giam_group", "justification"],
        [
            ["extern.asthana_ankit@allianz.de", "APP-GITHUB-ADMIN", "Onboarding"],
            ["sachin.lakhpati@allianz.com", "APP-GITHUB-READ", "Onboarding"],
        ],
    )
    rows, skipped = read_input_rows(path)
    assert skipped == []
    assert rows == [
        InputRow(recipient="extern.asthana_ankit@allianz.de", giam_group="APP-GITHUB-ADMIN", justification="Onboarding"),
        InputRow(recipient="sachin.lakhpati@allianz.com", giam_group="APP-GITHUB-READ", justification="Onboarding"),
    ]


def test_read_input_rows_skips_blank_rows(tmp_path):
    path = tmp_path / "input.xlsx"
    _write_workbook(
        path,
        ["recipient", "giam_group", "justification"],
        [
            ["extern.asthana_ankit@allianz.de", "APP-GITHUB-ADMIN", "Onboarding"],
            [None, None, None],
        ],
    )
    rows, skipped = read_input_rows(path)
    assert len(rows) == 1
    assert skipped == []


def test_read_input_rows_missing_column_raises(tmp_path):
    path = tmp_path / "input.xlsx"
    _write_workbook(path, ["recipient", "justification"], [["a@b.com", "Onboarding"]])
    with pytest.raises(ValueError, match="recipient, giam_group, justification"):
        read_input_rows(path)


def test_read_input_rows_case_insensitive_headers(tmp_path):
    path = tmp_path / "input.xlsx"
    _write_workbook(
        path,
        ["Recipient", "GIAM_GROUP", "Justification"],
        [
            ["user@example.com", "APP-ADMIN", "Access needed"],
        ],
    )
    rows, skipped = read_input_rows(path)
    assert skipped == []
    assert rows == [
        InputRow(recipient="user@example.com", giam_group="APP-ADMIN", justification="Access needed"),
    ]


def test_read_input_rows_reordered_headers(tmp_path):
    path = tmp_path / "input.xlsx"
    _write_workbook(
        path,
        ["justification", "recipient", "giam_group"],
        [
            ["Access needed", "user@example.com", "APP-ADMIN"],
        ],
    )
    rows, skipped = read_input_rows(path)
    assert skipped == []
    assert rows == [
        InputRow(recipient="user@example.com", giam_group="APP-ADMIN", justification="Access needed"),
    ]


def test_read_input_rows_reports_rows_with_missing_recipient_or_group(tmp_path):
    path = tmp_path / "input.xlsx"
    _write_workbook(
        path,
        ["recipient", "giam_group", "justification"],
        [
            ["a@b.com", "APP-GITHUB-ADMIN", "Onboarding"],   # data row 1: valid
            [None, "APP-GITHUB-READ", "Onboarding"],         # data row 2: no recipient
            ["c@b.com", "   ", "Onboarding"],                # data row 3: blank group
            ["d@b.com", "APP-GITHUB-READ", "Onboarding"],    # data row 4: valid
        ],
    )

    rows, skipped = read_input_rows(path)

    assert rows == [
        InputRow(recipient="a@b.com", giam_group="APP-GITHUB-ADMIN", justification="Onboarding"),
        InputRow(recipient="d@b.com", giam_group="APP-GITHUB-READ", justification="Onboarding"),
    ]
    assert skipped == [(2, "missing recipient"), (3, "missing giam_group")]
